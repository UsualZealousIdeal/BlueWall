package com.bluewall.simulator.ui.components

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.bluewall.simulator.data.local.OfflineMediaStorage
import com.bluewall.simulator.data.local.entity.CharacterEntity
import com.bluewall.simulator.ui.theme.BlueWallColors
import kotlinx.coroutines.launch

private val relationshipOptions = listOf(
    "Single",
    "In a relationship",
    "Engaged",
    "Married",
    "It's complicated",
    "Not specified"
)

@Composable
fun CharacterEditorDialog(
    existingCharacter: CharacterEntity?,
    onDismiss: () -> Unit,
    onSave: (
        name: String,
        headline: String,
        workplaceOrSchool: String,
        hometown: String,
        relationshipStatus: String,
        avatarStyle: String,
        avatarColorHex: Long,
        coverColorHex: Long,
        profilePhotoPath: String?,
        coverPhotoPath: String?,
        switchToNew: Boolean
    ) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val isEditing = existingCharacter != null

    var name by remember(existingCharacter) { mutableStateOf(existingCharacter?.name ?: "") }
    var headline by remember(existingCharacter) { mutableStateOf(existingCharacter?.headline ?: "") }
    var workplace by remember(existingCharacter) {
        mutableStateOf(existingCharacter?.workplaceOrSchool ?: "")
    }
    var hometown by remember(existingCharacter) { mutableStateOf(existingCharacter?.hometown ?: "") }
    var relationship by remember(existingCharacter) {
        mutableStateOf(existingCharacter?.relationshipStatus ?: "Single")
    }
    var avatarStyle by remember(existingCharacter) {
        mutableStateOf(existingCharacter?.avatarStyle ?: AvatarCatalog.styles.first().key)
    }
    var avatarColorHex by remember(existingCharacter) {
        mutableLongStateOf(existingCharacter?.avatarColorHex ?: AvatarCatalog.colors.first().avatarHex)
    }
    var coverColorHex by remember(existingCharacter) {
        mutableLongStateOf(existingCharacter?.coverColorHex ?: AvatarCatalog.colors.first().coverHex)
    }
    var profilePhotoPath by remember(existingCharacter) {
        mutableStateOf(existingCharacter?.profilePhotoPath)
    }
    var coverPhotoPath by remember(existingCharacter) {
        mutableStateOf(existingCharacter?.coverPhotoPath)
    }
    var switchToNew by remember { mutableStateOf(true) }

    val profilePhotoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val imported = OfflineMediaStorage.importImageFromUri(context, uri)
                if (imported != null) {
                    profilePhotoPath = imported
                }
            }
        }
    }

    val coverPhotoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val imported = OfflineMediaStorage.importImageFromUri(context, uri)
                if (imported != null) {
                    coverPhotoPath = imported
                }
            }
        }
    }

    val previewCharacter = CharacterEntity(
        id = existingCharacter?.id ?: 0L,
        name = name.ifBlank { "New Character" },
        headline = headline,
        workplaceOrSchool = workplace,
        hometown = hometown,
        relationshipStatus = relationship,
        avatarStyle = avatarStyle,
        avatarColorHex = avatarColorHex,
        coverColorHex = coverColorHex,
        profilePhotoPath = profilePhotoPath,
        coverPhotoPath = coverPhotoPath
    )

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(6.dp),
            color = BlueWallColors.CardWhite,
            border = BorderStroke(1.dp, BlueWallColors.CardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Classic blue modal header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BlueWallColors.ClassicBlue)
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isEditing) "Edit Fictional Character" else "Create Fictional Character",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 490.dp)
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Cover Photo preview & upload control
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(82.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .border(1.dp, BlueWallColors.CardBorder, RoundedCornerShape(4.dp))
                            .background(
                                Brush.horizontalGradient(
                                    listOf(Color(coverColorHex), Color(avatarColorHex))
                                )
                            )
                    ) {
                        LocalFileImage(
                            path = coverPhotoPath,
                            contentDescription = "Cover photo preview",
                            contentScale = ContentScale.Crop,
                            reqMaxPx = 900,
                            modifier = Modifier.fillMaxSize()
                        )
                        Row(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(6.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            if (coverPhotoPath != null) {
                                Text(
                                    text = "Remove",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(3.dp))
                                        .background(Color.Black.copy(alpha = 0.65f))
                                        .clickable { coverPhotoPath = null }
                                        .padding(horizontal = 7.dp, vertical = 4.dp)
                                )
                            }
                            Text(
                                text = if (coverPhotoPath != null) "Change Cover" else "+ Upload Cover Photo",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(Color.Black.copy(alpha = 0.65f))
                                    .clickable {
                                        coverPhotoPicker.launch(
                                            PickVisualMediaRequest(
                                                ActivityResultContracts.PickVisualMedia.ImageOnly
                                            )
                                        )
                                    }
                                    .padding(horizontal = 7.dp, vertical = 4.dp)
                            )
                        }
                    }

                    // Live profile photo preview & upload button
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CharacterAvatar(character = previewCharacter, size = 62.dp)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = previewCharacter.name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = BlueWallColors.TextPrimary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        profilePhotoPicker.launch(
                                            PickVisualMediaRequest(
                                                ActivityResultContracts.PickVisualMedia.ImageOnly
                                            )
                                        )
                                    },
                                    shape = RoundedCornerShape(3.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    modifier = Modifier.height(30.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.AddPhotoAlternate,
                                        contentDescription = null,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (profilePhotoPath != null) "Change Photo" else "Profile Photo",
                                        fontSize = 11.sp
                                    )
                                }

                                if (profilePhotoPath != null) {
                                    TextButton(
                                        onClick = { profilePhotoPath = null },
                                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                        modifier = Modifier.height(30.dp)
                                    ) {
                                        Text(
                                            text = "Remove",
                                            color = BlueWallColors.DangerRed,
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Character Name *") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = headline,
                        onValueChange = { headline = it },
                        label = { Text("Bio / Tagline") },
                        maxLines = 2,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = workplace,
                        onValueChange = { workplace = it },
                        label = { Text("School or Workplace") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = hometown,
                        onValueChange = { hometown = it },
                        label = { Text("Hometown") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text(
                        text = "Relationship Status",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = BlueWallColors.TextSecondary
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        relationshipOptions.forEach { option ->
                            val selected = relationship == option
                            Text(
                                text = option,
                                fontSize = 12.sp,
                                color = if (selected) Color.White else BlueWallColors.TextPrimary,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(
                                        if (selected) BlueWallColors.ClassicBlue
                                        else BlueWallColors.SubBarSurface
                                    )
                                    .border(1.dp, BlueWallColors.CardBorder, RoundedCornerShape(3.dp))
                                    .clickable { relationship = option }
                                    .padding(horizontal = 9.dp, vertical = 5.dp)
                            )
                        }
                    }

                    Text(
                        text = "Fallback Portrait Style",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = BlueWallColors.TextSecondary
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        AvatarCatalog.styles.forEach { style ->
                            val selected = avatarStyle == style.key
                            Text(
                                text = style.label,
                                fontSize = 12.sp,
                                color = if (selected) Color.White else BlueWallColors.TextPrimary,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(
                                        if (selected) BlueWallColors.ClassicBlue
                                        else BlueWallColors.SubBarSurface
                                    )
                                    .border(1.dp, BlueWallColors.CardBorder, RoundedCornerShape(3.dp))
                                    .clickable { avatarStyle = style.key }
                                    .padding(horizontal = 9.dp, vertical = 5.dp)
                            )
                        }
                    }

                    Text(
                        text = "Theme Color",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = BlueWallColors.TextSecondary
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        AvatarCatalog.colors.forEach { colorOption ->
                            val selected = avatarColorHex == colorOption.avatarHex
                            Box(
                                modifier = Modifier
                                    .size(30.dp)
                                    .clip(CircleShape)
                                    .background(Color(colorOption.avatarHex))
                                    .border(
                                        width = if (selected) 3.dp else 1.dp,
                                        color = if (selected) BlueWallColors.TextPrimary else BlueWallColors.CardBorder,
                                        shape = CircleShape
                                    )
                                    .clickable {
                                        avatarColorHex = colorOption.avatarHex
                                        coverColorHex = colorOption.coverHex
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                if (selected) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = colorOption.label,
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }

                    if (!isEditing) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { switchToNew = !switchToNew },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = switchToNew,
                                onCheckedChange = { switchToNew = it }
                            )
                            Text(
                                text = "Switch to this character immediately",
                                fontSize = 13.sp,
                                color = BlueWallColors.TextPrimary
                            )
                        }
                    }
                }

                HorizontalDivider(color = BlueWallColors.SubtleDivider)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BlueWallColors.SubBarSurface)
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = BlueWallColors.TextSecondary)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            onSave(
                                name,
                                headline,
                                workplace,
                                hometown,
                                relationship,
                                avatarStyle,
                                avatarColorHex,
                                coverColorHex,
                                profilePhotoPath,
                                coverPhotoPath,
                                switchToNew
                            )
                        },
                        enabled = name.isNotBlank(),
                        shape = RoundedCornerShape(3.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = BlueWallColors.ClassicButtonBlue
                        )
                    ) {
                        Text(
                            text = if (isEditing) "Save Changes" else "Create Character",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun QuickCharacterSwitcherDialog(
    characters: List<CharacterEntity>,
    activeCharacterId: Long?,
    onDismiss: () -> Unit,
    onSelectCharacter: (CharacterEntity) -> Unit,
    onCreateNewCharacter: () -> Unit,
    onManageCharacters: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(6.dp),
            color = BlueWallColors.CardWhite,
            border = BorderStroke(1.dp, BlueWallColors.CardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BlueWallColors.ClassicBlue)
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Switch Active Character",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 320.dp)
                ) {
                    items(characters, key = { it.id }) { character ->
                        val isActive = character.id == activeCharacterId
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    if (isActive) BlueWallColors.ClassicBlueTint.copy(alpha = 0.55f)
                                    else Color.White
                                )
                                .clickable {
                                    onSelectCharacter(character)
                                    onDismiss()
                                }
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CharacterAvatar(character = character, size = 38.dp)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = character.name,
                                    color = BlueWallColors.TextPrimary,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (character.headline.isNotBlank()) {
                                    Text(
                                        text = character.headline,
                                        color = BlueWallColors.TextSecondary,
                                        fontSize = 11.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            if (isActive) {
                                Text(
                                    text = "ACTIVE",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(3.dp))
                                        .background(BlueWallColors.ClassicBlue)
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        HorizontalDivider(color = BlueWallColors.SubtleDivider)
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BlueWallColors.SubBarSurface)
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = {
                            onDismiss()
                            onCreateNewCharacter()
                        },
                        shape = RoundedCornerShape(3.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("New", fontSize = 12.sp)
                    }

                    Row {
                        TextButton(onClick = {
                            onDismiss()
                            onManageCharacters()
                        }) {
                            Text("Manage All", color = BlueWallColors.LinkBlue, fontWeight = FontWeight.Bold)
                        }
                        TextButton(onClick = onDismiss) {
                            Text("Close", color = BlueWallColors.TextSecondary)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DeleteCharacterConfirmDialog(
    character: CharacterEntity,
    onDismiss: () -> Unit,
    onConfirmDelete: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Delete ${character.name}?",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Text(
                text = "This permanently removes ${character.name}, along with their posts and comments from the local Room database."
            )
        },
        confirmButton = {
            Button(
                onClick = onConfirmDelete,
                colors = ButtonDefaults.buttonColors(containerColor = BlueWallColors.DangerRed)
            ) {
                Text("Delete")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
