package com.bluewall.simulator.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bluewall.simulator.data.local.OfflineMediaStorage
import com.bluewall.simulator.data.local.entity.CharacterEntity
import com.bluewall.simulator.data.local.model.PostWithDetails
import com.bluewall.simulator.ui.components.CharacterAvatar
import com.bluewall.simulator.ui.components.LocalFileImage
import com.bluewall.simulator.ui.components.PostCard
import com.bluewall.simulator.ui.components.PostComposerCard
import com.bluewall.simulator.ui.theme.BlueWallColors
import kotlinx.coroutines.launch

@Composable
fun ProfileScreen(
    profileCharacter: CharacterEntity?,
    activeCharacter: CharacterEntity?,
    wallPosts: List<PostWithDetails>,
    onSwitchToViewedCharacter: (CharacterEntity) -> Unit,
    onOpenMyProfile: () -> Unit,
    onEditCharacter: (CharacterEntity) -> Unit,
    onUpdateProfilePhoto: (CharacterEntity, String?) -> Unit,
    onUpdateCoverPhoto: (CharacterEntity, String?) -> Unit,
    onSwitchCharacterClick: () -> Unit,
    onAuthorClick: (Long) -> Unit,
    onPublishWallPost: (
        content: String,
        moodOrLocation: String?,
        photoSceneKey: String?,
        mediaPhotoPath: String?,
        targetProfileId: Long
    ) -> Unit,
    onToggleLike: (Long) -> Unit,
    onAddComment: (postId: Long, content: String) -> Unit,
    onDeletePost: (Long) -> Unit,
    onDeleteComment: (Long) -> Unit
) {
    if (profileCharacter == null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(BlueWallColors.FeedBackground),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "Select or create a character to view their profile.",
                color = BlueWallColors.TextSecondary
            )
        }
        return
    }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val isOwnProfile = activeCharacter?.id == profileCharacter.id

    val profilePhotoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val imported = OfflineMediaStorage.importImageFromUri(context, uri)
                if (imported != null) {
                    onUpdateProfilePhoto(profileCharacter, imported)
                }
            }
        }
    }

    val coverPhotoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val imported = OfflineMediaStorage.importImageFromUri(context, uri)
                if (imported != null) {
                    onUpdateCoverPhoto(profileCharacter, imported)
                }
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(BlueWallColors.FeedBackground),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        if (!isOwnProfile && activeCharacter != null) {
            item(key = "other_profile_banner") {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BlueWallColors.ClassicBlueTint)
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Viewing ${profileCharacter.name}'s Wall",
                        color = BlueWallColors.TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedButton(
                        onClick = onOpenMyProfile,
                        shape = RoundedCornerShape(3.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.height(28.dp)
                    ) {
                        Text("My Profile", fontSize = 11.sp)
                    }
                }
            }
        }

        item(key = "profile_header") {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                shape = RoundedCornerShape(4.dp),
                color = BlueWallColors.CardWhite,
                border = BorderStroke(1.dp, BlueWallColors.CardBorder)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    // Classic cover banner (uploaded photo or gradient)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(126.dp)
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(
                                        Color(profileCharacter.coverColorHex),
                                        Color(profileCharacter.avatarColorHex)
                                    )
                                )
                            )
                    ) {
                        LocalFileImage(
                            path = profileCharacter.coverPhotoPath,
                            contentDescription = "${profileCharacter.name}'s cover photo",
                            contentScale = ContentScale.Crop,
                            reqMaxPx = 1200,
                            modifier = Modifier.fillMaxSize()
                        )

                        if (isOwnProfile) {
                            Text(
                                text = "ACTIVE CHARACTER",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(10.dp)
                                    .background(
                                        Color.Black.copy(alpha = 0.45f),
                                        RoundedCornerShape(3.dp)
                                    )
                                    .padding(horizontal = 7.dp, vertical = 3.dp)
                            )
                        }

                        Row(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (profileCharacter.coverPhotoPath != null) {
                                Text(
                                    text = "Remove",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(3.dp))
                                        .background(Color.Black.copy(alpha = 0.58f))
                                        .clickable { onUpdateCoverPhoto(profileCharacter, null) }
                                        .padding(horizontal = 7.dp, vertical = 4.dp)
                                )
                            }
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(Color.Black.copy(alpha = 0.58f))
                                    .clickable {
                                        coverPhotoPicker.launch(
                                            PickVisualMediaRequest(
                                                ActivityResultContracts.PickVisualMedia.ImageOnly
                                            )
                                        )
                                    }
                                    .padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CameraAlt,
                                    contentDescription = "Change cover photo",
                                    tint = Color.White,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (profileCharacter.coverPhotoPath != null) "Change Cover" else "Add Cover Photo",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    // Avatar & Identity Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier.clickable {
                                profilePhotoPicker.launch(
                                    PickVisualMediaRequest(
                                        ActivityResultContracts.PickVisualMedia.ImageOnly
                                    )
                                )
                            }
                        ) {
                            CharacterAvatar(
                                character = profileCharacter,
                                size = 78.dp,
                                borderColor = BlueWallColors.CardBorder
                            )
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .padding(3.dp)
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(Color.Black.copy(alpha = 0.65f))
                                    .padding(3.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CameraAlt,
                                    contentDescription = "Change profile photo",
                                    tint = Color.White,
                                    modifier = Modifier.size(12.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = profileCharacter.name,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = BlueWallColors.TextPrimary
                            )
                            if (profileCharacter.headline.isNotBlank()) {
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = profileCharacter.headline,
                                    fontSize = 13.sp,
                                    color = BlueWallColors.TextSecondary
                                )
                            }
                        }
                    }

                    // Action Buttons
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp)
                            .padding(bottom = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (!isOwnProfile) {
                            Button(
                                onClick = { onSwitchToViewedCharacter(profileCharacter) },
                                shape = RoundedCornerShape(3.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = BlueWallColors.ClassicButtonBlue
                                ),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(34.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.SwapHoriz,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(
                                    "Act as ${profileCharacter.name}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        OutlinedButton(
                            onClick = { onEditCharacter(profileCharacter) },
                            shape = RoundedCornerShape(3.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = null,
                                tint = BlueWallColors.TextPrimary,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = "Edit Profile",
                                color = BlueWallColors.TextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    HorizontalDivider(color = BlueWallColors.SubtleDivider)

                    // Classic Info Box
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(BlueWallColors.SubBarSurface)
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "ABOUT",
                            color = BlueWallColors.TextMuted,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.6.sp
                        )
                        if (profileCharacter.workplaceOrSchool.isNotBlank()) {
                            ProfileInfoRow(
                                icon = Icons.Default.Work,
                                text = profileCharacter.workplaceOrSchool
                            )
                        }
                        if (profileCharacter.hometown.isNotBlank()) {
                            ProfileInfoRow(
                                icon = Icons.Default.Home,
                                text = "Lives in ${profileCharacter.hometown}"
                            )
                        }
                        if (profileCharacter.relationshipStatus.isNotBlank()) {
                            ProfileInfoRow(
                                icon = Icons.Default.Favorite,
                                text = profileCharacter.relationshipStatus
                            )
                        }
                    }
                }
            }
        }

        item(key = "wall_composer") {
            PostComposerCard(
                activeCharacter = activeCharacter,
                wallTargetCharacter = profileCharacter,
                onSwitchCharacterClick = onSwitchCharacterClick,
                onPublishPost = { content, mood, sceneKey, mediaPhotoPath ->
                    onPublishWallPost(
                        content,
                        mood,
                        sceneKey,
                        mediaPhotoPath,
                        profileCharacter.id
                    )
                }
            )
        }

        item(key = "wall_section_title") {
            Text(
                text = "Wall (${wallPosts.size})",
                color = BlueWallColors.TextSecondary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
            )
        }

        if (wallPosts.isEmpty()) {
            item(key = "empty_wall") {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(4.dp),
                    color = BlueWallColors.CardWhite,
                    border = BorderStroke(1.dp, BlueWallColors.CardBorder)
                ) {
                    Text(
                        text = "Nothing on ${profileCharacter.name}'s wall yet. Write the first post above!",
                        color = BlueWallColors.TextSecondary,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(18.dp)
                    )
                }
            }
        } else {
            items(wallPosts, key = { it.post.id }) { postDetails ->
                PostCard(
                    postDetails = postDetails,
                    activeCharacter = activeCharacter,
                    onAuthorClick = onAuthorClick,
                    onToggleLike = onToggleLike,
                    onAddComment = onAddComment,
                    onDeletePost = onDeletePost,
                    onDeleteComment = onDeleteComment
                )
            }
        }
    }
}

@Composable
private fun ProfileInfoRow(
    icon: ImageVector,
    text: String
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = BlueWallColors.TextMuted,
            modifier = Modifier.size(15.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = text,
            color = BlueWallColors.TextPrimary,
            fontSize = 13.sp
        )
    }
}
