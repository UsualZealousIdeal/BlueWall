package com.bluewall.simulator.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.bluewall.simulator.data.local.entity.CharacterEntity
import com.bluewall.simulator.data.local.model.PostWithDetails
import com.bluewall.simulator.data.repository.SimulatorRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class MainTab(val title: String) {
    NEWS_FEED("News Feed"),
    PROFILE("Profile"),
    CHARACTERS("Characters")
}

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(
    private val repository: SimulatorRepository
) : ViewModel() {

    private val _activeTab = MutableStateFlow(MainTab.NEWS_FEED)
    val activeTab: StateFlow<MainTab> = _activeTab.asStateFlow()

    private val _selectedProfileId = MutableStateFlow<Long?>(null)

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    val characters: StateFlow<List<CharacterEntity>> =
        repository.observeAllCharacters()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val activeCharacter: StateFlow<CharacterEntity?> =
        repository.observeActiveCharacter()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    val feedPosts: StateFlow<List<PostWithDetails>> =
        repository.observeFeedPosts()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val effectiveProfileId = combine(_selectedProfileId, activeCharacter) { selectedId, active ->
        selectedId ?: active?.id
    }

    val viewedProfileCharacter: StateFlow<CharacterEntity?> =
        effectiveProfileId
            .flatMapLatest { id ->
                if (id == null) flowOf(null) else repository.observeCharacterById(id)
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    val viewedProfilePosts: StateFlow<List<PostWithDetails>> =
        effectiveProfileId
            .flatMapLatest { id ->
                if (id == null) flowOf(emptyList()) else repository.observeWallPosts(id)
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    init {
        viewModelScope.launch {
            repository.ensureInitialized()
        }
    }

    fun selectTab(tab: MainTab) {
        if (tab == MainTab.PROFILE && _selectedProfileId.value == null) {
            _selectedProfileId.value = activeCharacter.value?.id
        }
        _activeTab.value = tab
    }

    fun openMyProfile() {
        _selectedProfileId.value = activeCharacter.value?.id
        _activeTab.value = MainTab.PROFILE
    }

    fun openCharacterProfile(characterId: Long) {
        _selectedProfileId.value = characterId
        _activeTab.value = MainTab.PROFILE
    }

    fun switchActiveCharacter(character: CharacterEntity) {
        viewModelScope.launch {
            repository.switchActiveCharacter(character.id)
            _statusMessage.value = "Now acting as ${character.name}"
        }
    }

    fun createCharacter(
        name: String,
        headline: String,
        workplaceOrSchool: String,
        hometown: String,
        relationshipStatus: String,
        avatarStyle: String,
        avatarColorHex: Long,
        coverColorHex: Long,
        profilePhotoPath: String?,
        coverPhotoPath: String?,
        switchToNew: Boolean
    ) {
        viewModelScope.launch {
            val newId = repository.createCharacter(
                name = name,
                headline = headline,
                workplaceOrSchool = workplaceOrSchool,
                hometown = hometown,
                relationshipStatus = relationshipStatus,
                avatarStyle = avatarStyle,
                avatarColorHex = avatarColorHex,
                coverColorHex = coverColorHex,
                profilePhotoPath = profilePhotoPath,
                coverPhotoPath = coverPhotoPath,
                switchToNew = switchToNew
            )
            if (switchToNew) {
                _selectedProfileId.value = newId
            }
            _statusMessage.value = "Created character ${name.trim()}"
        }
    }

    fun updateCharacter(character: CharacterEntity) {
        viewModelScope.launch {
            repository.updateCharacter(character)
            _statusMessage.value = "Updated ${character.name}"
        }
    }

    fun updateCharacterProfilePhoto(character: CharacterEntity, photoPath: String?) {
        viewModelScope.launch {
            repository.updateCharacter(character.copy(profilePhotoPath = photoPath))
            _statusMessage.value = if (photoPath != null) {
                "Updated ${character.name}'s profile photo"
            } else {
                "Removed ${character.name}'s profile photo"
            }
        }
    }

    fun updateCharacterCoverPhoto(character: CharacterEntity, photoPath: String?) {
        viewModelScope.launch {
            repository.updateCharacter(character.copy(coverPhotoPath = photoPath))
            _statusMessage.value = if (photoPath != null) {
                "Updated ${character.name}'s cover photo"
            } else {
                "Removed ${character.name}'s cover photo"
            }
        }
    }

    fun duplicateCharacter(
        source: CharacterEntity,
        copiedProfilePhotoPath: String? = source.profilePhotoPath,
        copiedCoverPhotoPath: String? = source.coverPhotoPath
    ) {
        viewModelScope.launch {
            repository.duplicateCharacter(
                source = source,
                copiedProfilePhotoPath = copiedProfilePhotoPath,
                copiedCoverPhotoPath = copiedCoverPhotoPath,
                switchToCopy = false
            )
            _statusMessage.value = "Duplicated ${source.name}"
        }
    }

    fun deleteCharacter(character: CharacterEntity) {
        viewModelScope.launch {
            val deleted = repository.deleteCharacter(character)
            if (!deleted) {
                _statusMessage.value = "Keep at least one character in the simulator."
            } else {
                if (_selectedProfileId.value == character.id) {
                    _selectedProfileId.value = null
                }
                _statusMessage.value = "Deleted ${character.name}"
            }
        }
    }

    fun publishPost(
        content: String,
        moodOrLocation: String?,
        photoSceneKey: String?,
        mediaPhotoPath: String? = null,
        targetProfileId: Long? = null
    ) {
        val current = activeCharacter.value ?: return
        viewModelScope.launch {
            repository.createPost(
                authorId = current.id,
                targetProfileId = targetProfileId,
                content = content,
                moodOrLocation = moodOrLocation,
                photoSceneKey = photoSceneKey,
                mediaPhotoPath = mediaPhotoPath
            )
        }
    }

    fun deletePost(postId: Long) {
        viewModelScope.launch {
            repository.deletePost(postId)
            _statusMessage.value = "Post removed"
        }
    }

    fun addComment(postId: Long, content: String) {
        val current = activeCharacter.value ?: return
        viewModelScope.launch {
            repository.addComment(
                postId = postId,
                authorId = current.id,
                content = content
            )
        }
    }

    fun deleteComment(commentId: Long) {
        viewModelScope.launch {
            repository.deleteComment(commentId)
        }
    }

    fun toggleLike(postId: Long) {
        val current = activeCharacter.value ?: return
        viewModelScope.launch {
            repository.toggleLike(postId = postId, characterId = current.id)
        }
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }
}

class MainViewModelFactory(
    private val repository: SimulatorRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
            return MainViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}
