package com.bluewall.simulator.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import com.bluewall.simulator.data.local.entity.CommentEntity
import com.bluewall.simulator.data.local.entity.PostEntity
import com.bluewall.simulator.data.local.entity.PostLikeEntity
import com.bluewall.simulator.data.local.model.PostWithDetails
import kotlinx.coroutines.flow.Flow

@Dao
interface PostDao {

    @Transaction
    @Query("SELECT * FROM posts ORDER BY createdAt DESC")
    fun observeFeedPosts(): Flow<List<PostWithDetails>>

    @Transaction
    @Query(
        """
        SELECT * FROM posts
        WHERE authorId = :characterId OR targetProfileId = :characterId
        ORDER BY createdAt DESC
        """
    )
    fun observeWallPosts(characterId: Long): Flow<List<PostWithDetails>>

    @Query("SELECT COUNT(*) FROM posts")
    suspend fun countPosts(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPost(post: PostEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPosts(posts: List<PostEntity>): List<Long>

    @Query("DELETE FROM posts WHERE id = :postId")
    suspend fun deletePostById(postId: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertComment(comment: CommentEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertComments(comments: List<CommentEntity>)

    @Query("DELETE FROM comments WHERE id = :commentId")
    suspend fun deleteCommentById(commentId: Long)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertLike(like: PostLikeEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertLikes(likes: List<PostLikeEntity>)

    @Query("DELETE FROM post_likes WHERE postId = :postId AND characterId = :characterId")
    suspend fun deleteLike(postId: Long, characterId: Long)

    @Query("SELECT EXISTS(SELECT 1 FROM post_likes WHERE postId = :postId AND characterId = :characterId)")
    suspend fun hasLiked(postId: Long, characterId: Long): Boolean
}
