package com.bluewall.simulator.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "posts",
    foreignKeys = [
        ForeignKey(
            entity = CharacterEntity::class,
            parentColumns = ["id"],
            childColumns = ["authorId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = CharacterEntity::class,
            parentColumns = ["id"],
            childColumns = ["targetProfileId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["authorId"]),
        Index(value = ["targetProfileId"]),
        Index(value = ["createdAt"])
    ]
)
data class PostEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val authorId: Long,
    val targetProfileId: Long? = null,
    val content: String,
    val moodOrLocation: String? = null,
    val photoSceneKey: String? = null,
    val mediaPhotoPath: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)
