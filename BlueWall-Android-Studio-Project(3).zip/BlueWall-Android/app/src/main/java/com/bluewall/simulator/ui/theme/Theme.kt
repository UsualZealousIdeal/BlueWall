package com.bluewall.simulator.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val ClassicColorScheme = lightColorScheme(
    primary = BlueWallColors.ClassicBlue,
    onPrimary = BlueWallColors.CardWhite,
    primaryContainer = BlueWallColors.ClassicBlueTint,
    onPrimaryContainer = BlueWallColors.TextPrimary,
    secondary = BlueWallColors.ClassicButtonBlue,
    onSecondary = BlueWallColors.CardWhite,
    background = BlueWallColors.FeedBackground,
    onBackground = BlueWallColors.TextPrimary,
    surface = BlueWallColors.CardWhite,
    onSurface = BlueWallColors.TextPrimary,
    surfaceVariant = BlueWallColors.CommentSurface,
    onSurfaceVariant = BlueWallColors.TextSecondary,
    outline = BlueWallColors.CardBorder,
    error = BlueWallColors.DangerRed
)

@Composable
fun BlueWallTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = ClassicColorScheme,
        typography = BlueWallTypography,
        content = content
    )
}
