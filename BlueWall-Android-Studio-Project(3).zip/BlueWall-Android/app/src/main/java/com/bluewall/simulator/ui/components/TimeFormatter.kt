package com.bluewall.simulator.ui.components

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object TimeFormatter {
    fun formatRelativeTimestamp(timestampMillis: Long, nowMillis: Long = System.currentTimeMillis()): String {
        val diff = (nowMillis - timestampMillis).coerceAtLeast(0L)
        val minute = 60_000L
        val hour = 60 * minute

        return when {
            diff < minute -> "Just now"
            diff < 2 * minute -> "1 min ago"
            diff < hour -> "${diff / minute} mins ago"
            diff < 2 * hour -> "1 hr ago"
            diff < 12 * hour -> "${diff / hour} hrs ago"
            isYesterday(timestampMillis, nowMillis) -> {
                val timeFmt = SimpleDateFormat("h:mm a", Locale.getDefault())
                "Yesterday at ${timeFmt.format(Date(timestampMillis))}"
            }
            else -> {
                val dateFmt = SimpleDateFormat("MMM d 'at' h:mm a", Locale.getDefault())
                dateFmt.format(Date(timestampMillis))
            }
        }
    }

    private fun isYesterday(targetMillis: Long, nowMillis: Long): Boolean {
        val targetCal = Calendar.getInstance().apply { timeInMillis = targetMillis }
        val yesterdayCal = Calendar.getInstance().apply {
            timeInMillis = nowMillis
            add(Calendar.DAY_OF_YEAR, -1)
        }
        return targetCal.get(Calendar.YEAR) == yesterdayCal.get(Calendar.YEAR) &&
            targetCal.get(Calendar.DAY_OF_YEAR) == yesterdayCal.get(Calendar.DAY_OF_YEAR)
    }
}
