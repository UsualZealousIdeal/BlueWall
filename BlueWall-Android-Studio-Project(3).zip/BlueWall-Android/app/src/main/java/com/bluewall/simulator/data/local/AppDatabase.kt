package com.bluewall.simulator.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.room.migration.Migration
import com.bluewall.simulator.data.local.dao.CharacterDao
import com.bluewall.simulator.data.local.dao.PostDao
import com.bluewall.simulator.data.local.entity.CharacterEntity
import com.bluewall.simulator.data.local.entity.CommentEntity
import com.bluewall.simulator.data.local.entity.PostEntity
import com.bluewall.simulator.data.local.entity.PostLikeEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

@Database(
    entities = [
        CharacterEntity::class,
        PostEntity::class,
        CommentEntity::class,
        PostLikeEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun characterDao(): CharacterDao
    abstract fun postDao(): PostDao

    companion object {
        private const val DATABASE_NAME = "bluewall_offline.db"

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE characters ADD COLUMN profilePhotoPath TEXT")
                db.execSQL("ALTER TABLE characters ADD COLUMN coverPhotoPath TEXT")
                db.execSQL("ALTER TABLE posts ADD COLUMN mediaPhotoPath TEXT")
            }
        }

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: buildDatabase(context.applicationContext).also { INSTANCE = it }
            }
        }

        private fun buildDatabase(appContext: Context): AppDatabase {
            val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
            return Room.databaseBuilder(
                appContext,
                AppDatabase::class.java,
                DATABASE_NAME
            )
                .addMigrations(MIGRATION_1_2)
                .addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        scope.launch {
                            INSTANCE?.let { database ->
                                SeedData.populate(database.characterDao(), database.postDao())
                            }
                        }
                    }
                })
                .build()
        }
    }
}
