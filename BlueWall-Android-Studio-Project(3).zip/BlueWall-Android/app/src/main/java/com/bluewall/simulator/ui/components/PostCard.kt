package com.bluewall.simulator.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.outlined.ThumbUp
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.bluewall.simulator.data.local.entity.CharacterEntity
import com.bluewall.simulator.data.local.model.PostWithDetails
import com.bluewall.simulator.ui.theme.BlueWallColors

@Composable
fun PostCard(
    postDetails: PostWithDetails,
    activeCharacter: CharacterEntity?,
    onAuthorClick: (Long) -> Unit,
    onToggleLike: (Long) -> Unit,
    onAddComment: (postId: Long, content: String) -> Unit,
    onDeletePost: (Long) -> Unit,
    onDeleteComment: (Long) -> Unit
) {
    val post = postDetails.post
    val author = postDetails.author
    val targetProfile = postDetails.targetProfile
    val sortedComments = remember(postDetails.comments) {
        postDetails.comments.sortedBy { it.comment.createdAt }
    }
    val hasLiked = remember(postDetails.likes, activeCharacter) {
        activeCharacter != null && postDetails.likes.any { it.character.id == activeCharacter.id }
    }

    var commentDraft by rememberSaveable(post.id) { mutableStateOf("") }
    var showCommentBox by rememberSaveable(post.id) { mutableStateOf(sortedComments.isNotEmpty()) }
    var showMenu by remember { mutableStateOf(false) }
    var showFullPhoto by remember { mutableStateOf(false) }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 5.dp),
        shape = RoundedCornerShape(4.dp),
        color = BlueWallColors.CardWhite,
        border = BorderStroke(1.dp, BlueWallColors.CardBorder)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Post header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 10.dp, end = 6.dp, top = 10.dp, bottom = 6.dp),
                verticalAlignment = Alignment.Top
            ) {
                CharacterAvatar(
                    character = author,
                    size = 42.dp,
                    modifier = Modifier.clickable { onAuthorClick(author.id) }
                )

                Spacer(modifier = Modifier.width(10.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = author.name,
                            color = BlueWallColors.LinkBlue,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.clickable { onAuthorClick(author.id) }
                        )

                        if (targetProfile != null) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "to",
                                tint = BlueWallColors.TextMuted,
                                modifier = Modifier
                                    .padding(horizontal = 4.dp)
                                    .size(13.dp)
                            )
                            Text(
                                text = targetProfile.name,
                                color = BlueWallColors.LinkBlue,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.clickable { onAuthorClick(targetProfile.id) }
                            )
                        }
                    }

                    if (!post.moodOrLocation.isNullOrBlank()) {
                        Text(
                            text = "— ${post.moodOrLocation}",
                            color = BlueWallColors.TextSecondary,
                            fontSize = 12.sp
                        )
                    }

                    Text(
                        text = TimeFormatter.formatRelativeTimestamp(post.createdAt),
                        color = BlueWallColors.TextMuted,
                        fontSize = 11.sp
                    )
                }

                Box {
                    IconButton(
                        onClick = { showMenu = true },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.MoreHoriz,
                            contentDescription = "Post options",
                            tint = BlueWallColors.TextMuted,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("View ${author.name}'s Profile") },
                            onClick = {
                                showMenu = false
                                onAuthorClick(author.id)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Delete Post", color = BlueWallColors.DangerRed) },
                            onClick = {
                                showMenu = false
                                onDeletePost(post.id)
                            }
                        )
                    }
                }
            }

            // Post text content
            if (post.content.isNotBlank()) {
                Text(
                    text = post.content,
                    color = BlueWallColors.TextPrimary,
                    fontSize = 14.sp,
                    lineHeight = 20.sp,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }

            // Uploaded media photo OR offline preset scene
            if (!post.mediaPhotoPath.isNullOrBlank()) {
                LocalFileImage(
                    path = post.mediaPhotoPath,
                    contentDescription = "Post photo by ${author.name}",
                    contentScale = ContentScale.Crop,
                    reqMaxPx = 1200,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .heightIn(min = 140.dp, max = 280.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .border(1.dp, BlueWallColors.CardBorder, RoundedCornerShape(3.dp))
                        .clickable { showFullPhoto = true }
                )
            } else if (!post.photoSceneKey.isNullOrBlank()) {
                OfflinePhotoScene(
                    sceneKey = post.photoSceneKey,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                )
            }

            if (showFullPhoto && !post.mediaPhotoPath.isNullOrBlank()) {
                Dialog(
                    onDismissRequest = { showFullPhoto = false },
                    properties = DialogProperties(usePlatformDefaultWidth = false)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.92f))
                            .clickable { showFullPhoto = false }
                    ) {
                        LocalFileImage(
                            path = post.mediaPhotoPath,
                            contentDescription = "Full size photo",
                            contentScale = ContentScale.Fit,
                            reqMaxPx = 1280,
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp)
                        )
                        IconButton(
                            onClick = { showFullPhoto = false },
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(16.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close photo",
                                tint = Color.White
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            HorizontalDivider(color = BlueWallColors.SubtleDivider)

            // Classic Like + Comment action bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BlueWallColors.SubBarSurface)
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(3.dp))
                        .clickable { onToggleLike(post.id) }
                        .padding(horizontal = 4.dp, vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (hasLiked) Icons.Filled.ThumbUp else Icons.Outlined.ThumbUp,
                        contentDescription = "Like",
                        tint = if (hasLiked) BlueWallColors.LikeActiveBlue else BlueWallColors.TextSecondary,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = if (hasLiked) "Unlike" else "Like",
                        color = if (hasLiked) BlueWallColors.LikeActiveBlue else BlueWallColors.TextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(3.dp))
                        .clickable { showCommentBox = true }
                        .padding(horizontal = 4.dp, vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.ChatBubbleOutline,
                        contentDescription = "Comment",
                        tint = BlueWallColors.TextSecondary,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = "Comment",
                        color = BlueWallColors.TextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.weight(1f))

                if (sortedComments.isNotEmpty()) {
                    Text(
                        text = "${sortedComments.size} ${if (sortedComments.size == 1) "comment" else "comments"}",
                        color = BlueWallColors.TextMuted,
                        fontSize = 11.sp
                    )
                }
            }

            // Classic indented #EDEFF4 likes + comments section
            if (postDetails.likes.isNotEmpty() || sortedComments.isNotEmpty() || showCommentBox) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BlueWallColors.CommentSurface)
                ) {
                    if (postDetails.likes.isNotEmpty()) {
                        HorizontalDivider(color = BlueWallColors.SubtleDivider)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Filled.ThumbUp,
                                contentDescription = null,
                                tint = BlueWallColors.ClassicBlue,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = formatLikeSummary(postDetails.likes.map { it.character.name }),
                                color = BlueWallColors.TextPrimary,
                                fontSize = 12.sp
                            )
                        }
                    }

                    sortedComments.forEach { item ->
                        HorizontalDivider(color = Color(0xFFDCDFE6))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            CharacterAvatar(
                                character = item.author,
                                size = 30.dp,
                                modifier = Modifier.clickable { onAuthorClick(item.author.id) }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = buildAnnotatedString {
                                        withStyle(
                                            SpanStyle(
                                                color = BlueWallColors.LinkBlue,
                                                fontWeight = FontWeight.Bold
                                            )
                                        ) {
                                            append(item.author.name)
                                        }
                                        append("  ")
                                        withStyle(SpanStyle(color = BlueWallColors.TextPrimary)) {
                                            append(item.comment.content)
                                        }
                                    },
                                    fontSize = 13.sp,
                                    lineHeight = 17.sp,
                                    modifier = Modifier.clickable { onAuthorClick(item.author.id) }
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = TimeFormatter.formatRelativeTimestamp(item.comment.createdAt),
                                    color = BlueWallColors.TextMuted,
                                    fontSize = 10.sp
                                )
                            }
                            IconButton(
                                onClick = { onDeleteComment(item.comment.id) },
                                modifier = Modifier.size(22.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DeleteOutline,
                                    contentDescription = "Delete comment",
                                    tint = BlueWallColors.TextMuted,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                    }

                    if (showCommentBox) {
                        HorizontalDivider(color = Color(0xFFDCDFE6))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CharacterAvatar(character = activeCharacter, size = 28.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(Color.White)
                                    .padding(horizontal = 8.dp, vertical = 7.dp)
                            ) {
                                if (commentDraft.isEmpty()) {
                                    Text(
                                        text = "Comment as ${activeCharacter?.name ?: "..."}...",
                                        color = BlueWallColors.TextMuted,
                                        fontSize = 12.sp
                                    )
                                }
                                BasicTextField(
                                    value = commentDraft,
                                    onValueChange = { commentDraft = it },
                                    textStyle = TextStyle(
                                        color = BlueWallColors.TextPrimary,
                                        fontSize = 13.sp
                                    ),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            IconButton(
                                onClick = {
                                    val clean = commentDraft.trim()
                                    if (clean.isNotEmpty()) {
                                        onAddComment(post.id, clean)
                                        commentDraft = ""
                                    }
                                },
                                enabled = commentDraft.isNotBlank() && activeCharacter != null,
                                modifier = Modifier.size(30.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Send,
                                    contentDescription = "Send comment",
                                    tint = if (commentDraft.isNotBlank()) BlueWallColors.ClassicBlue else BlueWallColors.TextMuted,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun formatLikeSummary(names: List<String>): String {
    return when (names.size) {
        0 -> ""
        1 -> "${names[0]} likes this."
        2 -> "${names[0]} and ${names[1]} like this."
        3 -> "${names[0]}, ${names[1]} and 1 other like this."
        else -> "${names[0]}, ${names[1]} and ${names.size - 2} others like this."
    }
}
