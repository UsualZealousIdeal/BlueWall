package com.bluewall.simulator.data.local

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

object OfflineMediaStorage {

    private const val MEDIA_DIR = "bluewall_media"
    private const val MAX_DIMENSION_PX = 1280

    private fun ensureMediaDir(context: Context): File {
        val dir = File(context.filesDir, MEDIA_DIR)
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }

    suspend fun importImageFromUri(context: Context, uri: Uri): String? =
        withContext(Dispatchers.IO) {
            try {
                val resolver = context.applicationContext.contentResolver
                val boundsOptions = BitmapFactory.Options().apply {
                    inJustDecodeBounds = true
                }
                resolver.openInputStream(uri)?.use { stream ->
                    BitmapFactory.decodeStream(stream, null, boundsOptions)
                }

                val sampleSize = calculateInSampleSize(
                    width = boundsOptions.outWidth,
                    height = boundsOptions.outHeight,
                    maxDimension = MAX_DIMENSION_PX
                )

                val decodeOptions = BitmapFactory.Options().apply {
                    inSampleSize = sampleSize
                }
                val decoded = resolver.openInputStream(uri)?.use { stream ->
                    BitmapFactory.decodeStream(stream, null, decodeOptions)
                } ?: return@withContext null

                val scaled = scaleDownIfNeeded(decoded, MAX_DIMENSION_PX)
                if (scaled !== decoded) {
                    decoded.recycle()
                }

                val outFile = File(ensureMediaDir(context), "img_${UUID.randomUUID()}.jpg")
                FileOutputStream(outFile).use { fos ->
                    scaled.compress(Bitmap.CompressFormat.JPEG, 88, fos)
                }
                scaled.recycle()
                outFile.absolutePath
            } catch (_: Exception) {
                null
            }
        }

    suspend fun copyImageFile(context: Context, sourcePath: String?): String? =
        withContext(Dispatchers.IO) {
            if (sourcePath.isNullOrBlank()) return@withContext null
            try {
                val src = File(sourcePath)
                if (!src.exists()) return@withContext null
                val dest = File(ensureMediaDir(context), "img_${UUID.randomUUID()}.jpg")
                src.copyTo(dest, overwrite = true)
                dest.absolutePath
            } catch (_: Exception) {
                null
            }
        }

    suspend fun decodeBitmapFromPath(path: String, reqMaxPx: Int = 1024): Bitmap? =
        withContext(Dispatchers.IO) {
            try {
                val file = File(path)
                if (!file.exists()) return@withContext null

                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(path, bounds)

                val opts = BitmapFactory.Options().apply {
                    inSampleSize = calculateInSampleSize(bounds.outWidth, bounds.outHeight, reqMaxPx)
                }
                BitmapFactory.decodeFile(path, opts)
            } catch (_: Exception) {
                null
            }
        }

    private fun calculateInSampleSize(width: Int, height: Int, maxDimension: Int): Int {
        var inSampleSize = 1
        if (width > maxDimension || height > maxDimension) {
            val halfWidth = width / 2
            val halfHeight = height / 2
            while ((halfWidth / inSampleSize) >= maxDimension &&
                (halfHeight / inSampleSize) >= maxDimension
            ) {
                inSampleSize *= 2
            }
        }
        return inSampleSize.coerceAtLeast(1)
    }

    private fun scaleDownIfNeeded(bitmap: Bitmap, maxDimension: Int): Bitmap {
        val w = bitmap.width
        val h = bitmap.height
        if (w <= maxDimension && h <= maxDimension) return bitmap
        val ratio = minOf(maxDimension.toFloat() / w, maxDimension.toFloat() / h)
        val targetW = (w * ratio).toInt().coerceAtLeast(1)
        val targetH = (h * ratio).toInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(bitmap, targetW, targetH, true)
    }
}
