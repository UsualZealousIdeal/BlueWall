package com.bluewall.simulator

import android.app.Application
import com.bluewall.simulator.data.local.AppDatabase
import com.bluewall.simulator.data.repository.SimulatorRepository

class BlueWallApplication : Application() {

    val database: AppDatabase by lazy {
        AppDatabase.getInstance(this)
    }

    val repository: SimulatorRepository by lazy {
        SimulatorRepository(
            characterDao = database.characterDao(),
            postDao = database.postDao()
        )
    }
}
