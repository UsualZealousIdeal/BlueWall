package com.bluewall.simulator.ui.theme

import androidx.compose.ui.graphics.Color

object BlueWallColors {
    val ClassicBlue = Color(0xFF3B5998)
    val ClassicBlueDark = Color(0xFF29487D)
    val ClassicBlueLight = Color(0xFF4E69A2)
    val ClassicButtonBlue = Color(0xFF5B74A8)
    val LinkBlue = Color(0xFF3B5998)
    val ActiveTabBlue = Color(0xFF4C70BA)

    val FeedBackground = Color(0xFFE9EBEE)
    val ClassicBlueTint = Color(0xFFD8DFEA)
    val CommentSurface = Color(0xFFEDEFF4)
    val SubBarSurface = Color(0xFFF6F7F9)
    val CardWhite = Color(0xFFFFFFFF)
    val CardBorder = Color(0xFFCBD2D9)
    val SubtleDivider = Color(0xFFE5E7EB)

    val TextPrimary = Color(0xFF1D2129)
    val TextSecondary = Color(0xFF606770)
    val TextMuted = Color(0xFF898F9C)

    val DrawerBackground = Color(0xFF32394A)
    val DrawerHeader = Color(0xFF262C3A)
    val DrawerDivider = Color(0xFF434C61)
    val DrawerText = Color(0xFFE9EEF7)
    val DrawerTextMuted = Color(0xFFA7B1C6)

    val LikeActiveBlue = Color(0xFF3B5998)
    val SuccessGreen = Color(0xFF42B72A)
    val DangerRed = Color(0xFFC62828)
}
