package com.bluewall.simulator.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.bluewall.simulator.data.local.entity.CharacterEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CharacterDao {

    @Query("SELECT * FROM characters ORDER BY isActive DESC, createdAt ASC")
    fun observeAllCharacters(): Flow<List<CharacterEntity>>

    @Query("SELECT * FROM characters WHERE isActive = 1 LIMIT 1")
    fun observeActiveCharacter(): Flow<CharacterEntity?>

    @Query("SELECT * FROM characters WHERE id = :id LIMIT 1")
    fun observeCharacterById(id: Long): Flow<CharacterEntity?>

    @Query("SELECT * FROM characters WHERE id = :id LIMIT 1")
    suspend fun getCharacterById(id: Long): CharacterEntity?

    @Query("SELECT * FROM characters ORDER BY createdAt ASC LIMIT 1")
    suspend fun getFirstCharacter(): CharacterEntity?

    @Query("SELECT COUNT(*) FROM characters")
    suspend fun countCharacters(): Int

    @Query("SELECT COUNT(*) FROM characters WHERE isActive = 1")
    suspend fun countActiveCharacters(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(character: CharacterEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(characters: List<CharacterEntity>): List<Long>

    @Update
    suspend fun update(character: CharacterEntity)

    @Query("DELETE FROM characters WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("UPDATE characters SET isActive = 0")
    suspend fun clearActiveFlags()

    @Query("UPDATE characters SET isActive = 1 WHERE id = :id")
    suspend fun markActive(id: Long)

    @Transaction
    suspend fun switchActiveCharacter(id: Long) {
        clearActiveFlags()
        markActive(id)
    }
}
