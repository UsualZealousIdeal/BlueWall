package com.bluewall.simulator.data.local

import com.bluewall.simulator.data.local.dao.CharacterDao
import com.bluewall.simulator.data.local.dao.PostDao
import com.bluewall.simulator.data.local.entity.CharacterEntity
import com.bluewall.simulator.data.local.entity.CommentEntity
import com.bluewall.simulator.data.local.entity.PostEntity
import com.bluewall.simulator.data.local.entity.PostLikeEntity

object SeedData {

    suspend fun populate(characterDao: CharacterDao, postDao: PostDao) {
        if (characterDao.countCharacters() > 0) return

        val now = System.currentTimeMillis()
        val minute = 60_000L
        val hour = 60 * minute
        val day = 24 * hour

        val initialCharacters = listOf(
            CharacterEntity(
                name = "Maya Lin",
                headline = "Architecture '13 • Living on iced lattes and tracing paper",
                workplaceOrSchool = "Pacific Coast Design College",
                hometown = "Portland, OR",
                relationshipStatus = "In a relationship",
                avatarStyle = "CLASSIC_BOB",
                avatarColorHex = 0xFF3B5998L,
                coverColorHex = 0xFF4E69A2L,
                isActive = true,
                createdAt = now - 30 * day
            ),
            CharacterEntity(
                name = "Marcus Vance",
                headline = "Campus radio DJ • Crate digger & late-night taco fan",
                workplaceOrSchool = "KBRU 89.5 College Radio",
                hometown = "Seattle, WA",
                relationshipStatus = "Single",
                avatarStyle = "HEADPHONES",
                avatarColorHex = 0xFF2E7D32L,
                coverColorHex = 0xFF388E3CL,
                isActive = false,
                createdAt = now - 28 * day
            ),
            CharacterEntity(
                name = "Chloe Bennett",
                headline = "Student newspaper editor • Always chasing the next scoop",
                workplaceOrSchool = "The Campus Chronicle",
                hometown = "San Francisco, CA",
                relationshipStatus = "It's complicated",
                avatarStyle = "GLASSES",
                avatarColorHex = 0xFF8E24AAL,
                coverColorHex = 0xFF6A1B9AL,
                isActive = false,
                createdAt = now - 25 * day
            ),
            CharacterEntity(
                name = "Devon Brooks",
                headline = "Track team & indie cinema club • Do not talk before 9am",
                workplaceOrSchool = "Oakridge Athletics",
                hometown = "Austin, TX",
                relationshipStatus = "Single",
                avatarStyle = "CAP",
                avatarColorHex = 0xFFD84315L,
                coverColorHex = 0xFFBF360CL,
                isActive = false,
                createdAt = now - 22 * day
            ),
            CharacterEntity(
                name = "Priya Patel",
                headline = "CS & Robotics • Debugging life one semicolon at a time",
                workplaceOrSchool = "Northgate Robotics Lab",
                hometown = "Boston, MA",
                relationshipStatus = "In a relationship",
                avatarStyle = "BUN",
                avatarColorHex = 0xFF00838FL,
                coverColorHex = 0xFF006064L,
                isActive = false,
                createdAt = now - 20 * day
            )
        )

        val ids = characterDao.insertAll(initialCharacters)
        val mayaId = ids[0]
        val marcusId = ids[1]
        val chloeId = ids[2]
        val devonId = ids[3]
        val priyaId = ids[4]

        val initialPosts = listOf(
            PostEntity(
                authorId = mayaId,
                targetProfileId = null,
                content = "Just finished pinning up the scale model for studio critique tomorrow morning. Three cups of coffee down, zero regrets.",
                moodOrLocation = "at Studio Annex B",
                photoSceneKey = "COFFEE_DESK",
                createdAt = now - 14 * minute
            ),
            PostEntity(
                authorId = marcusId,
                targetProfileId = mayaId,
                content = "Happy Friday Maya! Did you still want to borrow that Fleet Foxes vinyl for the weekend?",
                moodOrLocation = null,
                photoSceneKey = null,
                createdAt = now - 49 * minute
            ),
            PostEntity(
                authorId = chloeId,
                targetProfileId = null,
                content = "Caught the golden hour sky over the quad right after finishing tomorrow's front-page layout. Campus actually looks peaceful for once!",
                moodOrLocation = "at Main Quad",
                photoSceneKey = "CAMPUS_SUNSET",
                createdAt = now - 3 * hour
            ),
            PostEntity(
                authorId = devonId,
                targetProfileId = null,
                content = "Who decided an 8:00 AM Friday midterm was a reasonable human expectation? Asking for my alarm clock.",
                moodOrLocation = "feeling sleepy",
                photoSceneKey = null,
                createdAt = now - 6 * hour
            ),
            PostEntity(
                authorId = priyaId,
                targetProfileId = null,
                content = "Our autonomous rover finally navigated the hallway obstacle course without bumping into a single trash can. Pizza celebration at 8!",
                moodOrLocation = "feeling accomplished",
                photoSceneKey = null,
                createdAt = now - 1 * day + 4 * hour
            ),
            PostEntity(
                authorId = marcusId,
                targetProfileId = null,
                content = "Spinning late-night indie classics on the 10pm radio slot tonight. Drop your song requests on my wall!",
                moodOrLocation = "listening to KBRU 89.5",
                photoSceneKey = "VINYL_NIGHT",
                createdAt = now - 1 * day - 2 * hour
            ),
            PostEntity(
                authorId = mayaId,
                targetProfileId = null,
                content = "Throwback to last weekend's coastal highway drive before finals week took over all of our lives.",
                moodOrLocation = "at Highway 101",
                photoSceneKey = "ROAD_TRIP",
                createdAt = now - 2 * day - 5 * hour
            )
        )

        val postIds = postDao.insertPosts(initialPosts)

        val comments = listOf(
            CommentEntity(
                postId = postIds[0],
                authorId = chloeId,
                content = "That balsa wood staircase detail looks unreal! Good luck tomorrow morning!",
                createdAt = now - 9 * minute
            ),
            CommentEntity(
                postId = postIds[0],
                authorId = priyaId,
                content = "Save me some coffee, I am still stuck in the lab.",
                createdAt = now - 4 * minute
            ),
            CommentEntity(
                postId = postIds[1],
                authorId = mayaId,
                content = "YES! Swing by the studio after 4pm if you are near the quad!",
                createdAt = now - 31 * minute
            ),
            CommentEntity(
                postId = postIds[2],
                authorId = devonId,
                content = "Wait, that orange sky was real? I blinked and missed sunset completely.",
                createdAt = now - 2 * hour
            ),
            CommentEntity(
                postId = postIds[2],
                authorId = marcusId,
                content = "Frame-worthy shot Chloe.",
                createdAt = now - 95 * minute
            ),
            CommentEntity(
                postId = postIds[3],
                authorId = mayaId,
                content = "Hang in there! Waffle House run after?",
                createdAt = now - 5 * hour
            ),
            CommentEntity(
                postId = postIds[4],
                authorId = chloeId,
                content = "Can the Chronicle interview the rover for Monday's issue?",
                createdAt = now - 19 * hour
            ),
            CommentEntity(
                postId = postIds[5],
                authorId = devonId,
                content = "Play some Two Door Cinema Club!",
                createdAt = now - 1 * day - 1 * hour
            )
        )
        postDao.insertComments(comments)

        val likes = listOf(
            PostLikeEntity(postId = postIds[0], characterId = marcusId),
            PostLikeEntity(postId = postIds[0], characterId = chloeId),
            PostLikeEntity(postId = postIds[0], characterId = priyaId),
            PostLikeEntity(postId = postIds[1], characterId = mayaId),
            PostLikeEntity(postId = postIds[2], characterId = mayaId),
            PostLikeEntity(postId = postIds[2], characterId = devonId),
            PostLikeEntity(postId = postIds[3], characterId = marcusId),
            PostLikeEntity(postId = postIds[3], characterId = priyaId),
            PostLikeEntity(postId = postIds[4], characterId = mayaId),
            PostLikeEntity(postId = postIds[4], characterId = chloeId),
            PostLikeEntity(postId = postIds[4], characterId = devonId),
            PostLikeEntity(postId = postIds[5], characterId = mayaId),
            PostLikeEntity(postId = postIds[6], characterId = chloeId),
            PostLikeEntity(postId = postIds[6], characterId = marcusId)
        )
        postDao.insertLikes(likes)
    }
}
