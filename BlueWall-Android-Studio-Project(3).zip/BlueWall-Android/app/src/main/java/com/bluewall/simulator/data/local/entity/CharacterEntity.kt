package com.bluewall.simulator.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "characters")
data class CharacterEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val name: String,
    val headline: String,
    val workplaceOrSchool: String,
    val hometown: String,
    val relationshipStatus: String,
    val avatarStyle: String,
    val avatarColorHex: Long,
    val coverColorHex: Long,
    val profilePhotoPath: String? = null,
    val coverPhotoPath: String? = null,
    val isActive: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
