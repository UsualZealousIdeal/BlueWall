package com.bluewall.simulator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import com.bluewall.simulator.ui.BlueWallApp
import com.bluewall.simulator.ui.theme.BlueWallTheme
import com.bluewall.simulator.ui.viewmodel.MainViewModel
import com.bluewall.simulator.ui.viewmodel.MainViewModelFactory

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val repository = (application as BlueWallApplication).repository
        setContent {
            BlueWallTheme {
                val viewModel: MainViewModel = viewModel(
                    factory = MainViewModelFactory(repository)
                )
                BlueWallApp(viewModel = viewModel)
            }
        }
    }
}
