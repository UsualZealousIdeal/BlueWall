package com.bluewall.simulator.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.bluewall.simulator.data.local.OfflineMediaStorage
import com.bluewall.simulator.data.local.entity.CharacterEntity
import com.bluewall.simulator.ui.components.CharacterEditorDialog
import com.bluewall.simulator.ui.components.ClassicTopBar
import com.bluewall.simulator.ui.components.DeleteCharacterConfirmDialog
import com.bluewall.simulator.ui.components.NavigationDrawerContent
import com.bluewall.simulator.ui.components.QuickCharacterSwitcherDialog
import com.bluewall.simulator.ui.screens.CharacterManagerScreen
import com.bluewall.simulator.ui.screens.NewsFeedScreen
import com.bluewall.simulator.ui.screens.ProfileScreen
import com.bluewall.simulator.ui.theme.BlueWallColors
import com.bluewall.simulator.ui.viewmodel.MainTab
import com.bluewall.simulator.ui.viewmodel.MainViewModel
import kotlinx.coroutines.launch

@Composable
fun BlueWallApp(viewModel: MainViewModel) {
    val context = LocalContext.current
    val activeTab by viewModel.activeTab.collectAsStateWithLifecycle()
    val characters by viewModel.characters.collectAsStateWithLifecycle()
    val activeCharacter by viewModel.activeCharacter.collectAsStateWithLifecycle()
    val feedPosts by viewModel.feedPosts.collectAsStateWithLifecycle()
    val viewedProfileCharacter by viewModel.viewedProfileCharacter.collectAsStateWithLifecycle()
    val viewedProfilePosts by viewModel.viewedProfilePosts.collectAsStateWithLifecycle()
    val statusMessage by viewModel.statusMessage.collectAsStateWithLifecycle()

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    var showSwitcherDialog by remember { mutableStateOf(false) }
    var showCreateDialog by remember { mutableStateOf(false) }
    var editingCharacter by remember { mutableStateOf<CharacterEntity?>(null) }
    var deletingCharacter by remember { mutableStateOf<CharacterEntity?>(null) }

    LaunchedEffect(statusMessage) {
        val message = statusMessage
        if (message != null) {
            snackbarHostState.showSnackbar(message)
            viewModel.clearStatusMessage()
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            NavigationDrawerContent(
                activeCharacter = activeCharacter,
                allCharacters = characters,
                onNavigateFeed = {
                    viewModel.selectTab(MainTab.NEWS_FEED)
                    scope.launch { drawerState.close() }
                },
                onNavigateMyProfile = {
                    viewModel.openMyProfile()
                    scope.launch { drawerState.close() }
                },
                onNavigateCharacterManager = {
                    viewModel.selectTab(MainTab.CHARACTERS)
                    scope.launch { drawerState.close() }
                },
                onOpenNewCharacterDialog = {
                    scope.launch { drawerState.close() }
                    showCreateDialog = true
                },
                onSwitchCharacter = { character ->
                    viewModel.switchActiveCharacter(character)
                    scope.launch { drawerState.close() }
                }
            )
        }
    ) {
        Scaffold(
            modifier = Modifier
                .fillMaxSize()
                .imePadding(),
            containerColor = BlueWallColors.FeedBackground,
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            topBar = {
                ClassicTopBar(
                    activeCharacter = activeCharacter,
                    activeTab = activeTab,
                    characterCount = characters.size,
                    onMenuClick = { scope.launch { drawerState.open() } },
                    onSwitchCharacterClick = { showSwitcherDialog = true },
                    onTabSelected = { tab ->
                        if (tab == MainTab.PROFILE) {
                            viewModel.openMyProfile()
                        } else {
                            viewModel.selectTab(tab)
                        }
                    }
                )
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (activeTab) {
                    MainTab.NEWS_FEED -> {
                        NewsFeedScreen(
                            activeCharacter = activeCharacter,
                            posts = feedPosts,
                            onSwitchCharacterClick = { showSwitcherDialog = true },
                            onAuthorClick = { id -> viewModel.openCharacterProfile(id) },
                            onPublishPost = { content, mood, sceneKey, mediaPhotoPath ->
                                viewModel.publishPost(
                                    content = content,
                                    moodOrLocation = mood,
                                    photoSceneKey = sceneKey,
                                    mediaPhotoPath = mediaPhotoPath,
                                    targetProfileId = null
                                )
                            },
                            onToggleLike = { postId -> viewModel.toggleLike(postId) },
                            onAddComment = { postId, content -> viewModel.addComment(postId, content) },
                            onDeletePost = { postId -> viewModel.deletePost(postId) },
                            onDeleteComment = { commentId -> viewModel.deleteComment(commentId) }
                        )
                    }
                    MainTab.PROFILE -> {
                        ProfileScreen(
                            profileCharacter = viewedProfileCharacter,
                            activeCharacter = activeCharacter,
                            wallPosts = viewedProfilePosts,
                            onSwitchToViewedCharacter = { character ->
                                viewModel.switchActiveCharacter(character)
                            },
                            onOpenMyProfile = { viewModel.openMyProfile() },
                            onEditCharacter = { character -> editingCharacter = character },
                            onUpdateProfilePhoto = { character, photoPath ->
                                viewModel.updateCharacterProfilePhoto(character, photoPath)
                            },
                            onUpdateCoverPhoto = { character, photoPath ->
                                viewModel.updateCharacterCoverPhoto(character, photoPath)
                            },
                            onSwitchCharacterClick = { showSwitcherDialog = true },
                            onAuthorClick = { id -> viewModel.openCharacterProfile(id) },
                            onPublishWallPost = { content, mood, sceneKey, mediaPhotoPath, targetId ->
                                viewModel.publishPost(
                                    content = content,
                                    moodOrLocation = mood,
                                    photoSceneKey = sceneKey,
                                    mediaPhotoPath = mediaPhotoPath,
                                    targetProfileId = targetId
                                )
                            },
                            onToggleLike = { postId -> viewModel.toggleLike(postId) },
                            onAddComment = { postId, content -> viewModel.addComment(postId, content) },
                            onDeletePost = { postId -> viewModel.deletePost(postId) },
                            onDeleteComment = { commentId -> viewModel.deleteComment(commentId) }
                        )
                    }
                    MainTab.CHARACTERS -> {
                        CharacterManagerScreen(
                            characters = characters,
                            activeCharacter = activeCharacter,
                            onCreateCharacterClick = { showCreateDialog = true },
                            onSwitchCharacter = { character -> viewModel.switchActiveCharacter(character) },
                            onViewProfile = { id -> viewModel.openCharacterProfile(id) },
                            onEditCharacter = { character -> editingCharacter = character },
                            onDuplicateCharacter = { character ->
                                scope.launch {
                                    val copiedProfile = OfflineMediaStorage.copyImageFile(
                                        context,
                                        character.profilePhotoPath
                                    )
                                    val copiedCover = OfflineMediaStorage.copyImageFile(
                                        context,
                                        character.coverPhotoPath
                                    )
                                    viewModel.duplicateCharacter(
                                        source = character,
                                        copiedProfilePhotoPath = copiedProfile,
                                        copiedCoverPhotoPath = copiedCover
                                    )
                                }
                            },
                            onRequestDeleteCharacter = { character -> deletingCharacter = character }
                        )
                    }
                }
            }
        }
    }

    if (showSwitcherDialog) {
        QuickCharacterSwitcherDialog(
            characters = characters,
            activeCharacterId = activeCharacter?.id,
            onDismiss = { showSwitcherDialog = false },
            onSelectCharacter = { character -> viewModel.switchActiveCharacter(character) },
            onCreateNewCharacter = { showCreateDialog = true },
            onManageCharacters = { viewModel.selectTab(MainTab.CHARACTERS) }
        )
    }

    if (showCreateDialog) {
        CharacterEditorDialog(
            existingCharacter = null,
            onDismiss = { showCreateDialog = false },
            onSave = { name, headline, workplace, hometown, relationship, style, avatarHex, coverHex, profilePhotoPath, coverPhotoPath, switchToNew ->
                viewModel.createCharacter(
                    name = name,
                    headline = headline,
                    workplaceOrSchool = workplace,
                    hometown = hometown,
                    relationshipStatus = relationship,
                    avatarStyle = style,
                    avatarColorHex = avatarHex,
                    coverColorHex = coverHex,
                    profilePhotoPath = profilePhotoPath,
                    coverPhotoPath = coverPhotoPath,
                    switchToNew = switchToNew
                )
                showCreateDialog = false
            }
        )
    }

    val charToEdit = editingCharacter
    if (charToEdit != null) {
        CharacterEditorDialog(
            existingCharacter = charToEdit,
            onDismiss = { editingCharacter = null },
            onSave = { name, headline, workplace, hometown, relationship, style, avatarHex, coverHex, profilePhotoPath, coverPhotoPath, _ ->
                viewModel.updateCharacter(
                    charToEdit.copy(
                        name = name,
                        headline = headline,
                        workplaceOrSchool = workplace,
                        hometown = hometown,
                        relationshipStatus = relationship,
                        avatarStyle = style,
                        avatarColorHex = avatarHex,
                        coverColorHex = coverHex,
                        profilePhotoPath = profilePhotoPath,
                        coverPhotoPath = coverPhotoPath
                    )
                )
                editingCharacter = null
            }
        )
    }

    val charToDelete = deletingCharacter
    if (charToDelete != null) {
        DeleteCharacterConfirmDialog(
            character = charToDelete,
            onDismiss = { deletingCharacter = null },
            onConfirmDelete = {
                viewModel.deleteCharacter(charToDelete)
                deletingCharacter = null
            }
        )
    }
}
