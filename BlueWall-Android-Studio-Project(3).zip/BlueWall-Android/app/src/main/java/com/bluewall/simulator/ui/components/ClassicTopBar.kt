package com.bluewall.simulator.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.DynamicFeed
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bluewall.simulator.data.local.entity.CharacterEntity
import com.bluewall.simulator.ui.theme.BlueWallColors
import com.bluewall.simulator.ui.viewmodel.MainTab

@Composable
fun ClassicTopBar(
    activeCharacter: CharacterEntity?,
    activeTab: MainTab,
    characterCount: Int,
    onMenuClick: () -> Unit,
    onSwitchCharacterClick: () -> Unit,
    onTabSelected: (MainTab) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(BlueWallColors.ClassicBlueDark)
            .statusBarsPadding()
    ) {
        // Classic 2010-2012 blue navigation bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            BlueWallColors.ClassicBlueLight,
                            BlueWallColors.ClassicBlue
                        )
                    )
                )
                .padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onMenuClick) {
                Icon(
                    imageVector = Icons.Default.Menu,
                    contentDescription = "Open navigation drawer",
                    tint = Color.White
                )
            }

            Text(
                text = "bluewall",
                color = Color.White,
                fontSize = 23.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = (-0.6).sp
            )

            Spacer(modifier = Modifier.weight(1f))

            // Prominent currently selected character switcher
            Row(
                modifier = Modifier
                    .padding(end = 8.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(BlueWallColors.ClassicBlueDark.copy(alpha = 0.85f))
                    .border(
                        width = 1.dp,
                        color = Color.White.copy(alpha = 0.28f),
                        shape = RoundedCornerShape(4.dp)
                    )
                    .clickable(onClick = onSwitchCharacterClick)
                    .padding(horizontal = 8.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CharacterAvatar(
                    character = activeCharacter,
                    size = 24.dp,
                    borderColor = Color.White.copy(alpha = 0.7f)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Column(modifier = Modifier.width(96.dp)) {
                    Text(
                        text = "ACTING AS",
                        color = Color(0xFFBAC8E6),
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = activeCharacter?.name ?: "Select...",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Icon(
                    imageVector = Icons.Default.ArrowDropDown,
                    contentDescription = "Switch character",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        HorizontalDivider(thickness = 1.dp, color = BlueWallColors.ClassicBlueDark)

        // Classic secondary navigation tab strip
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(BlueWallColors.SubBarSurface),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            ClassicTabItem(
                label = "News Feed",
                icon = Icons.Default.DynamicFeed,
                selected = activeTab == MainTab.NEWS_FEED,
                onClick = { onTabSelected(MainTab.NEWS_FEED) },
                modifier = Modifier.weight(1f)
            )
            ClassicTabItem(
                label = "Profile",
                icon = Icons.Default.Person,
                selected = activeTab == MainTab.PROFILE,
                onClick = { onTabSelected(MainTab.PROFILE) },
                modifier = Modifier.weight(1f)
            )
            ClassicTabItem(
                label = "Characters ($characterCount)",
                icon = Icons.Default.Group,
                selected = activeTab == MainTab.CHARACTERS,
                onClick = { onTabSelected(MainTab.CHARACTERS) },
                modifier = Modifier.weight(1f)
            )
        }
        HorizontalDivider(thickness = 1.dp, color = BlueWallColors.CardBorder)
    }
}

@Composable
private fun ClassicTabItem(
    label: String,
    icon: ImageVector,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val contentColor = if (selected) BlueWallColors.ClassicBlue else BlueWallColors.TextSecondary
    Column(
        modifier = modifier
            .clickable(onClick = onClick)
            .background(if (selected) BlueWallColors.CardWhite else BlueWallColors.SubBarSurface)
            .padding(top = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier.padding(horizontal = 4.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = contentColor,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
                text = label,
                color = contentColor,
                fontSize = 12.sp,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(modifier = Modifier.height(7.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(3.dp)
                .background(if (selected) BlueWallColors.ClassicBlue else Color.Transparent)
        )
    }
}
