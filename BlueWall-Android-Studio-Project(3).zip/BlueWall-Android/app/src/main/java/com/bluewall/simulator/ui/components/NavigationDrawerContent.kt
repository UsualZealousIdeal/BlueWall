package com.bluewall.simulator.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircleOutline
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DynamicFeed
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bluewall.simulator.data.local.entity.CharacterEntity
import com.bluewall.simulator.ui.theme.BlueWallColors

@Composable
fun NavigationDrawerContent(
    activeCharacter: CharacterEntity?,
    allCharacters: List<CharacterEntity>,
    onNavigateFeed: () -> Unit,
    onNavigateMyProfile: () -> Unit,
    onNavigateCharacterManager: () -> Unit,
    onOpenNewCharacterDialog: () -> Unit,
    onSwitchCharacter: (CharacterEntity) -> Unit
) {
    ModalDrawerSheet(
        modifier = Modifier.width(292.dp),
        drawerContainerColor = BlueWallColors.DrawerBackground,
        drawerContentColor = BlueWallColors.DrawerText
    ) {
        Column(
            modifier = Modifier
                .fillMaxHeight()
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            // Active Character Header
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BlueWallColors.DrawerHeader)
                    .clickable(onClick = onNavigateMyProfile)
                    .padding(16.dp)
            ) {
                Text(
                    text = "CURRENTLY ACTING AS",
                    color = Color(0xFF8FA4CC),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.8.sp
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CharacterAvatar(
                        character = activeCharacter,
                        size = 48.dp,
                        borderColor = Color.White.copy(alpha = 0.5f)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = activeCharacter?.name ?: "No Character",
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (!activeCharacter?.headline.isNullOrBlank()) {
                            Text(
                                text = activeCharacter?.headline.orEmpty(),
                                color = BlueWallColors.DrawerTextMuted,
                                fontSize = 12.sp,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }

            HorizontalDivider(color = BlueWallColors.DrawerDivider)

            LazyColumn(modifier = Modifier.weight(1f)) {
                item {
                    DrawerSectionLabel("FAVORITES")
                    DrawerMenuItem(
                        icon = Icons.Default.DynamicFeed,
                        label = "News Feed",
                        onClick = onNavigateFeed
                    )
                    DrawerMenuItem(
                        icon = Icons.Default.Person,
                        label = "My Profile & Wall",
                        onClick = onNavigateMyProfile
                    )
                    DrawerMenuItem(
                        icon = Icons.Default.Group,
                        label = "Character Manager",
                        onClick = onNavigateCharacterManager
                    )
                    DrawerMenuItem(
                        icon = Icons.Default.AddCircleOutline,
                        label = "New Fictional Character",
                        onClick = onOpenNewCharacterDialog
                    )
                    HorizontalDivider(
                        color = BlueWallColors.DrawerDivider,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                    DrawerSectionLabel("QUICK SWITCH CHARACTER")
                }

                items(allCharacters, key = { it.id }) { character ->
                    val isCurrent = character.id == activeCharacter?.id
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                if (isCurrent) BlueWallColors.ClassicBlue.copy(alpha = 0.45f)
                                else Color.Transparent
                            )
                            .clickable { onSwitchCharacter(character) }
                            .padding(horizontal = 16.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CharacterAvatar(
                            character = character,
                            size = 30.dp,
                            borderColor = if (isCurrent) Color.White else BlueWallColors.DrawerDivider
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = character.name,
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (character.workplaceOrSchool.isNotBlank()) {
                                Text(
                                    text = character.workplaceOrSchool,
                                    color = BlueWallColors.DrawerTextMuted,
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                        if (isCurrent) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Active",
                                tint = Color(0xFF7CE871),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            HorizontalDivider(color = BlueWallColors.DrawerDivider)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BlueWallColors.DrawerHeader)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    tint = BlueWallColors.DrawerTextMuted,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(3.dp))
                ) {
                    Text(
                        text = "Private Offline Simulator • Room SQLite",
                        color = BlueWallColors.DrawerTextMuted,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun DrawerSectionLabel(text: String) {
    Text(
        text = text,
        color = Color(0xFF8C97AD),
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 0.7.sp,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 6.dp)
    )
}

@Composable
private fun DrawerMenuItem(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = BlueWallColors.DrawerText,
            modifier = Modifier.size(19.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Text(
            text = label,
            color = BlueWallColors.DrawerText,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium
        )
    }
}
