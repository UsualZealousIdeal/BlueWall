package com.bluewall.simulator.ui.components

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Mood
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bluewall.simulator.data.local.OfflineMediaStorage
import com.bluewall.simulator.data.local.entity.CharacterEntity
import com.bluewall.simulator.ui.theme.BlueWallColors
import kotlinx.coroutines.launch

private val moodPresets = listOf(
    "feeling happy",
    "at the Coffee Shop",
    "listening to indie rock",
    "studying at the library",
    "feeling inspired"
)

@Composable
fun PostComposerCard(
    activeCharacter: CharacterEntity?,
    wallTargetCharacter: CharacterEntity? = null,
    onSwitchCharacterClick: () -> Unit,
    onPublishPost: (
        content: String,
        moodOrLocation: String?,
        photoSceneKey: String?,
        mediaPhotoPath: String?
    ) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var postText by rememberSaveable { mutableStateOf("") }
    var selectedMood by rememberSaveable { mutableStateOf<String?>(null) }
    var customMoodText by rememberSaveable { mutableStateOf("") }
    var showMoodPicker by remember { mutableStateOf(false) }
    var showPhotoPicker by remember { mutableStateOf(false) }
    var selectedSceneKey by rememberSaveable { mutableStateOf<String?>(null) }
    var selectedMediaPhotoPath by rememberSaveable { mutableStateOf<String?>(null) }

    val mediaPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val imported = OfflineMediaStorage.importImageFromUri(context, uri)
                if (imported != null) {
                    selectedMediaPhotoPath = imported
                    selectedSceneKey = null
                    showPhotoPicker = false
                }
            }
        }
    }

    val isWritingOnOtherWall =
        wallTargetCharacter != null && activeCharacter != null && wallTargetCharacter.id != activeCharacter.id

    val placeholderText = if (isWritingOnOtherWall) {
        "Write something on ${wallTargetCharacter?.name}'s wall..."
    } else {
        "What's on your mind?"
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 6.dp),
        shape = RoundedCornerShape(4.dp),
        color = BlueWallColors.CardWhite,
        border = BorderStroke(1.dp, BlueWallColors.CardBorder)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Classic 2011 composer header bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BlueWallColors.SubBarSurface)
                    .padding(horizontal = 10.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Edit,
                    contentDescription = null,
                    tint = BlueWallColors.ClassicBlue,
                    modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isWritingOnOtherWall) {
                        "Post to ${wallTargetCharacter?.name}'s Wall"
                    } else {
                        "Update Status"
                    },
                    color = BlueWallColors.TextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.weight(1f))
                Text(
                    text = "Posting as ${activeCharacter?.name ?: "..."}",
                    color = BlueWallColors.LinkBlue,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clickable(onClick = onSwitchCharacterClick)
                )
            }

            HorizontalDivider(color = BlueWallColors.SubtleDivider)

            // Main input area with active character portrait
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp),
                verticalAlignment = Alignment.Top
            ) {
                CharacterAvatar(character = activeCharacter, size = 40.dp)
                Spacer(modifier = Modifier.width(10.dp))
                OutlinedTextField(
                    value = postText,
                    onValueChange = { postText = it },
                    placeholder = {
                        Text(
                            text = placeholderText,
                            color = BlueWallColors.TextMuted,
                            fontSize = 14.sp
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2,
                    maxLines = 5,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = BlueWallColors.ClassicBlue,
                        unfocusedBorderColor = BlueWallColors.CardBorder,
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color(0xFFFCFCFD)
                    ),
                    shape = RoundedCornerShape(3.dp)
                )
            }

            // Selected mood / uploaded image / scene preview
            val activeMood = selectedMood ?: customMoodText.trim().takeIf { it.isNotEmpty() }
            if (activeMood != null || selectedSceneKey != null || selectedMediaPhotoPath != null) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp)
                        .padding(bottom = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (activeMood != null) {
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(3.dp))
                                .background(BlueWallColors.CommentSurface)
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "— $activeMood",
                                color = BlueWallColors.ClassicBlue,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Remove",
                                color = BlueWallColors.TextMuted,
                                fontSize = 11.sp,
                                modifier = Modifier.clickable {
                                    selectedMood = null
                                    customMoodText = ""
                                }
                            )
                        }
                    }

                    if (selectedMediaPhotoPath != null) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(3.dp))
                                .border(1.dp, BlueWallColors.CardBorder, RoundedCornerShape(3.dp))
                                .background(BlueWallColors.SubBarSurface)
                        ) {
                            LocalFileImage(
                                path = selectedMediaPhotoPath,
                                contentDescription = "Selected post photo",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(150.dp)
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 8.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Uploaded Photo Attached",
                                    color = BlueWallColors.TextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    text = "Remove",
                                    color = BlueWallColors.DangerRed,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.clickable { selectedMediaPhotoPath = null }
                                )
                            }
                        }
                    } else if (selectedSceneKey != null) {
                        val scene = AvatarCatalog.photoScenes.find { it.key == selectedSceneKey }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(3.dp))
                                .background(BlueWallColors.CommentSurface)
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Scene attached: ${scene?.label ?: selectedSceneKey}",
                                color = BlueWallColors.TextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = "Clear",
                                color = BlueWallColors.LinkBlue,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.clickable { selectedSceneKey = null }
                            )
                        }
                    }
                }
            }

            if (showMoodPicker) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BlueWallColors.SubBarSurface)
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        moodPresets.forEach { preset ->
                            val isSelected = selectedMood == preset
                            Text(
                                text = preset,
                                color = if (isSelected) Color.White else BlueWallColors.TextPrimary,
                                fontSize = 11.sp,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(
                                        if (isSelected) BlueWallColors.ClassicBlue
                                        else Color.White
                                    )
                                    .border(
                                        1.dp,
                                        BlueWallColors.CardBorder,
                                        RoundedCornerShape(3.dp)
                                    )
                                    .clickable {
                                        selectedMood = if (isSelected) null else preset
                                        customMoodText = ""
                                    }
                                    .padding(horizontal = 8.dp, vertical = 5.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = customMoodText,
                        onValueChange = {
                            customMoodText = it
                            if (it.isNotBlank()) selectedMood = null
                        },
                        placeholder = {
                            Text("Or type mood/location (e.g. at Central Park)", fontSize = 12.sp)
                        },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(3.dp)
                    )
                }
            }

            if (showPhotoPicker) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BlueWallColors.SubBarSurface)
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            mediaPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        shape = RoundedCornerShape(3.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddPhotoAlternate,
                            contentDescription = null,
                            tint = BlueWallColors.ClassicBlue,
                            modifier = Modifier.size(17.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Upload Image from Device",
                            color = BlueWallColors.ClassicBlue,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Text(
                        text = "Or pick an offline preset scene:",
                        color = BlueWallColors.TextSecondary,
                        fontSize = 11.sp
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        AvatarCatalog.photoScenes.forEach { scene ->
                            val isSelected = selectedSceneKey == scene.key
                            Column(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(
                                        if (isSelected) BlueWallColors.ClassicBlue else Color.White
                                    )
                                    .border(1.dp, BlueWallColors.CardBorder, RoundedCornerShape(3.dp))
                                    .clickable {
                                        selectedSceneKey = if (isSelected) null else scene.key
                                        if (!isSelected) selectedMediaPhotoPath = null
                                    }
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = scene.label,
                                    color = if (isSelected) Color.White else BlueWallColors.TextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = scene.caption,
                                    color = if (isSelected) Color(0xFFD8E4FF) else BlueWallColors.TextSecondary,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }
            }

            HorizontalDivider(color = BlueWallColors.SubtleDivider)

            // Bottom action strip
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BlueWallColors.SubBarSurface)
                    .padding(horizontal = 10.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(3.dp))
                        .clickable {
                            showMoodPicker = !showMoodPicker
                            if (showMoodPicker) showPhotoPicker = false
                        }
                        .padding(horizontal = 6.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Mood,
                        contentDescription = "Add mood or location",
                        tint = BlueWallColors.TextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Mood / Place",
                        color = BlueWallColors.TextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(3.dp))
                        .clickable {
                            showPhotoPicker = !showPhotoPicker
                            if (showPhotoPicker) showMoodPicker = false
                        }
                        .padding(horizontal = 6.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.PhotoLibrary,
                        contentDescription = "Attach photo",
                        tint = BlueWallColors.TextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Photo",
                        color = BlueWallColors.TextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Spacer(modifier = Modifier.weight(1f))

                val canPost =
                    postText.isNotBlank() || selectedSceneKey != null || selectedMediaPhotoPath != null
                Button(
                    onClick = {
                        onPublishPost(
                            postText,
                            activeMood,
                            selectedSceneKey,
                            selectedMediaPhotoPath
                        )
                        postText = ""
                        selectedMood = null
                        customMoodText = ""
                        selectedSceneKey = null
                        selectedMediaPhotoPath = null
                        showMoodPicker = false
                        showPhotoPicker = false
                    },
                    enabled = canPost && activeCharacter != null,
                    shape = RoundedCornerShape(3.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = BlueWallColors.ClassicButtonBlue,
                        contentColor = Color.White,
                        disabledContainerColor = BlueWallColors.CardBorder,
                        disabledContentColor = Color.White
                    ),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                    modifier = Modifier.height(32.dp)
                ) {
                    Text(
                        text = "Post",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
