package com.bluewall.simulator.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bluewall.simulator.data.local.OfflineMediaStorage
import com.bluewall.simulator.data.local.entity.CharacterEntity
import com.bluewall.simulator.ui.theme.BlueWallColors

data class AvatarStyleOption(
    val key: String,
    val label: String
)

data class AvatarColorOption(
    val label: String,
    val avatarHex: Long,
    val coverHex: Long
)

data class PhotoSceneOption(
    val key: String,
    val label: String,
    val caption: String
)

object AvatarCatalog {
    val styles = listOf(
        AvatarStyleOption("CLASSIC_BOB", "Classic"),
        AvatarStyleOption("HEADPHONES", "DJ / Audio"),
        AvatarStyleOption("GLASSES", "Bookish"),
        AvatarStyleOption("CAP", "Varsity Cap"),
        AvatarStyleOption("BEANIE", "Beanie"),
        AvatarStyleOption("BUN", "Top Bun"),
        AvatarStyleOption("CURLY", "Curly"),
        AvatarStyleOption("STAR", "Badge")
    )

    val colors = listOf(
        AvatarColorOption("Classic Blue", 0xFF3B5998L, 0xFF4E69A2L),
        AvatarColorOption("Forest Green", 0xFF2E7D32L, 0xFF388E3CL),
        AvatarColorOption("Plum Violet", 0xFF8E24AAL, 0xFF6A1B9AL),
        AvatarColorOption("Burnt Sienna", 0xFFD84315L, 0xFFBF360CL),
        AvatarColorOption("Ocean Teal", 0xFF00838FL, 0xFF006064L),
        AvatarColorOption("Crimson", 0xFFC62828L, 0xFF8E0000L),
        AvatarColorOption("Slate Navy", 0xFF37474FL, 0xFF263238L),
        AvatarColorOption("Amber Gold", 0xFFEF6C00L, 0xFFE65100L)
    )

    val photoScenes = listOf(
        PhotoSceneOption("COFFEE_DESK", "Studio Coffee", "Drafting desk & latte"),
        PhotoSceneOption("CAMPUS_SUNSET", "Campus Sunset", "Golden hour over the quad"),
        PhotoSceneOption("VINYL_NIGHT", "Late Vinyl", "Turntable & warm glow"),
        PhotoSceneOption("ROAD_TRIP", "Coastal Drive", "Highway 101 horizon")
    )
}

@Composable
fun LocalFileImage(
    path: String?,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop,
    reqMaxPx: Int = 1024,
    fallback: @Composable () -> Unit = {}
) {
    val bitmap by produceState<ImageBitmap?>(initialValue = null, key1 = path, key2 = reqMaxPx) {
        value = if (path.isNullOrBlank()) {
            null
        } else {
            OfflineMediaStorage.decodeBitmapFromPath(path, reqMaxPx)?.asImageBitmap()
        }
    }

    val loaded = bitmap
    if (loaded != null) {
        Image(
            bitmap = loaded,
            contentDescription = contentDescription,
            contentScale = contentScale,
            modifier = modifier
        )
    } else {
        fallback()
    }
}

@Composable
fun CharacterAvatar(
    character: CharacterEntity?,
    size: Dp = 44.dp,
    modifier: Modifier = Modifier,
    borderColor: Color = BlueWallColors.CardBorder
) {
    val bgColor = Color(character?.avatarColorHex ?: 0xFF3B5998L)
    val style = character?.avatarStyle ?: "CLASSIC_BOB"
    val initials = (character?.name ?: "?")
        .trim()
        .split(Regex("\\s+"))
        .filter { it.isNotEmpty() }
        .take(2)
        .joinToString("") { it.first().uppercaseChar().toString() }
        .ifEmpty { "?" }

    Surface(
        modifier = modifier.size(size),
        shape = RoundedCornerShape(4.dp),
        border = BorderStroke(1.dp, borderColor),
        color = bgColor
    ) {
        LocalFileImage(
            path = character?.profilePhotoPath,
            contentDescription = character?.name,
            modifier = Modifier.fillMaxSize(),
            reqMaxPx = 384,
            fallback = {
                Box(modifier = Modifier.fillMaxSize()) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                val w = this.size.width
                val h = this.size.height

                // Subtle 2011 gradient sheen
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.16f),
                            Color.Transparent,
                            Color.Black.copy(alpha = 0.18f)
                        )
                    )
                )

                // Shoulders silhouette
                drawCircle(
                    color = Color.White.copy(alpha = 0.90f),
                    radius = w * 0.36f,
                    center = Offset(w * 0.50f, h * 0.96f)
                )

                // Neck
                drawRect(
                    color = Color(0xFFF3D2C1),
                    topLeft = Offset(w * 0.43f, h * 0.56f),
                    size = Size(w * 0.14f, h * 0.16f)
                )

                // Face
                drawCircle(
                    color = Color(0xFFF6DBC8),
                    radius = w * 0.21f,
                    center = Offset(w * 0.50f, h * 0.43f)
                )

                // Eyes
                val eyeColor = Color(0xFF263238)
                drawCircle(eyeColor, radius = w * 0.025f, center = Offset(w * 0.43f, h * 0.43f))
                drawCircle(eyeColor, radius = w * 0.025f, center = Offset(w * 0.57f, h * 0.43f))

                // Smile
                drawArc(
                    color = Color(0xFF7A4B3A),
                    startAngle = 20f,
                    sweepAngle = 140f,
                    useCenter = false,
                    topLeft = Offset(w * 0.43f, h * 0.45f),
                    size = Size(w * 0.14f, h * 0.08f),
                    style = Stroke(width = (w * 0.025f).coerceAtLeast(1.5f))
                )

                // Style-specific hair or accessory
                when (style) {
                    "CLASSIC_BOB" -> {
                        drawArc(
                            color = Color(0xFF2B2320),
                            startAngle = 165f,
                            sweepAngle = 210f,
                            useCenter = true,
                            topLeft = Offset(w * 0.26f, h * 0.18f),
                            size = Size(w * 0.48f, h * 0.42f)
                        )
                    }
                    "HEADPHONES" -> {
                        drawArc(
                            color = Color(0xFF2D2520),
                            startAngle = 180f,
                            sweepAngle = 180f,
                            useCenter = true,
                            topLeft = Offset(w * 0.29f, h * 0.20f),
                            size = Size(w * 0.42f, h * 0.26f)
                        )
                        drawArc(
                            color = Color(0xFF212121),
                            startAngle = 180f,
                            sweepAngle = 180f,
                            useCenter = false,
                            topLeft = Offset(w * 0.24f, h * 0.16f),
                            size = Size(w * 0.52f, h * 0.48f),
                            style = Stroke(width = w * 0.06f)
                        )
                        drawRoundRect(
                            color = Color(0xFF37474F),
                            topLeft = Offset(w * 0.20f, h * 0.34f),
                            size = Size(w * 0.09f, h * 0.19f),
                            cornerRadius = CornerRadius(6f, 6f)
                        )
                        drawRoundRect(
                            color = Color(0xFF37474F),
                            topLeft = Offset(w * 0.71f, h * 0.34f),
                            size = Size(w * 0.09f, h * 0.19f),
                            cornerRadius = CornerRadius(6f, 6f)
                        )
                    }
                    "GLASSES" -> {
                        drawArc(
                            color = Color(0xFF5D3A24),
                            startAngle = 175f,
                            sweepAngle = 190f,
                            useCenter = true,
                            topLeft = Offset(w * 0.27f, h * 0.18f),
                            size = Size(w * 0.46f, h * 0.30f)
                        )
                        val frameStroke = Stroke(width = (w * 0.03f).coerceAtLeast(1.8f))
                        drawRect(
                            color = Color(0xFF1F242D),
                            topLeft = Offset(w * 0.34f, h * 0.38f),
                            size = Size(w * 0.14f, h * 0.10f),
                            style = frameStroke
                        )
                        drawRect(
                            color = Color(0xFF1F242D),
                            topLeft = Offset(w * 0.52f, h * 0.38f),
                            size = Size(w * 0.14f, h * 0.10f),
                            style = frameStroke
                        )
                        drawLine(
                            color = Color(0xFF1F242D),
                            start = Offset(w * 0.48f, h * 0.42f),
                            end = Offset(w * 0.52f, h * 0.42f),
                            strokeWidth = (w * 0.025f).coerceAtLeast(1.5f)
                        )
                    }
                    "CAP" -> {
                        drawArc(
                            color = Color(0xFF1E3A5F),
                            startAngle = 180f,
                            sweepAngle = 180f,
                            useCenter = true,
                            topLeft = Offset(w * 0.27f, h * 0.18f),
                            size = Size(w * 0.46f, h * 0.32f)
                        )
                        drawRoundRect(
                            color = Color(0xFF152943),
                            topLeft = Offset(w * 0.28f, h * 0.31f),
                            size = Size(w * 0.52f, h * 0.06f),
                            cornerRadius = CornerRadius(4f, 4f)
                        )
                    }
                    "BEANIE" -> {
                        drawArc(
                            color = Color(0xFFB71C1C),
                            startAngle = 180f,
                            sweepAngle = 180f,
                            useCenter = true,
                            topLeft = Offset(w * 0.28f, h * 0.16f),
                            size = Size(w * 0.44f, h * 0.34f)
                        )
                        drawRoundRect(
                            color = Color(0xFF8E0000),
                            topLeft = Offset(w * 0.27f, h * 0.30f),
                            size = Size(w * 0.46f, h * 0.07f),
                            cornerRadius = CornerRadius(4f, 4f)
                        )
                    }
                    "BUN" -> {
                        drawCircle(
                            color = Color(0xFF1E1B18),
                            radius = w * 0.11f,
                            center = Offset(w * 0.50f, h * 0.17f)
                        )
                        drawArc(
                            color = Color(0xFF1E1B18),
                            startAngle = 180f,
                            sweepAngle = 180f,
                            useCenter = true,
                            topLeft = Offset(w * 0.28f, h * 0.20f),
                            size = Size(w * 0.44f, h * 0.26f)
                        )
                    }
                    "CURLY" -> {
                        val curlColor = Color(0xFF3E2723)
                        drawCircle(curlColor, radius = w * 0.11f, center = Offset(w * 0.33f, h * 0.28f))
                        drawCircle(curlColor, radius = w * 0.11f, center = Offset(w * 0.50f, h * 0.22f))
                        drawCircle(curlColor, radius = w * 0.11f, center = Offset(w * 0.67f, h * 0.28f))
                        drawCircle(curlColor, radius = w * 0.09f, center = Offset(w * 0.28f, h * 0.40f))
                        drawCircle(curlColor, radius = w * 0.09f, center = Offset(w * 0.72f, h * 0.40f))
                    }
                    else -> {
                        drawArc(
                            color = Color(0xFF37474F),
                            startAngle = 180f,
                            sweepAngle = 180f,
                            useCenter = true,
                            topLeft = Offset(w * 0.29f, h * 0.20f),
                            size = Size(w * 0.42f, h * 0.24f)
                        )
                    }
                }
            }

            if (size >= 56.dp) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(3.dp)
                        .background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(3.dp))
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                ) {
                    Text(
                        text = initials,
                        color = Color.White,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
                }
            }
        )
    }
}

@Composable
fun OfflinePhotoScene(
    sceneKey: String,
    modifier: Modifier = Modifier
) {
    val sceneMeta = AvatarCatalog.photoScenes.find { it.key == sceneKey }
        ?: PhotoSceneOption(sceneKey, "Snapshot", "Offline photo memory")

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(3.dp))
            .border(1.dp, BlueWallColors.CardBorder, RoundedCornerShape(3.dp))
            .background(Color(0xFFFAFAFA))
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(150.dp)
        ) {
            val w = size.width
            val h = size.height

            when (sceneKey) {
                "COFFEE_DESK" -> {
                    drawRect(
                        brush = Brush.verticalGradient(
                            listOf(Color(0xFFEDE0D4), Color(0xFFDDB892))
                        )
                    )
                    // Blueprint sheet
                    drawRoundRect(
                        color = Color(0xFF3B5998),
                        topLeft = Offset(w * 0.08f, h * 0.16f),
                        size = Size(w * 0.52f, h * 0.68f),
                        cornerRadius = CornerRadius(6f, 6f)
                    )
                    drawRect(
                        color = Color.White.copy(alpha = 0.35f),
                        topLeft = Offset(w * 0.13f, h * 0.24f),
                        size = Size(w * 0.42f, h * 0.52f),
                        style = Stroke(width = 2.5f)
                    )
                    drawLine(
                        color = Color.White.copy(alpha = 0.5f),
                        start = Offset(w * 0.13f, h * 0.45f),
                        end = Offset(w * 0.55f, h * 0.45f),
                        strokeWidth = 2f
                    )
                    // Coffee mug
                    drawCircle(
                        color = Color(0xFFFDFDFD),
                        radius = h * 0.22f,
                        center = Offset(w * 0.77f, h * 0.54f)
                    )
                    drawCircle(
                        color = Color(0xFF6F4E37),
                        radius = h * 0.16f,
                        center = Offset(w * 0.77f, h * 0.54f)
                    )
                    drawCircle(
                        color = Color(0xFFF5E6D3).copy(alpha = 0.75f),
                        radius = h * 0.06f,
                        center = Offset(w * 0.75f, h * 0.52f)
                    )
                }
                "CAMPUS_SUNSET" -> {
                    drawRect(
                        brush = Brush.verticalGradient(
                            listOf(
                                Color(0xFF4A3B6B),
                                Color(0xFFD96B43),
                                Color(0xFFF4B942)
                            )
                        )
                    )
                    drawCircle(
                        color = Color(0xFFFFF3B0),
                        radius = h * 0.24f,
                        center = Offset(w * 0.62f, h * 0.52f)
                    )
                    val hillPath = Path().apply {
                        moveTo(0f, h)
                        lineTo(0f, h * 0.68f)
                        lineTo(w * 0.35f, h * 0.56f)
                        lineTo(w * 0.70f, h * 0.66f)
                        lineTo(w, h * 0.58f)
                        lineTo(w, h)
                        close()
                    }
                    drawPath(hillPath, color = Color(0xFF283044))
                    // Campus clocktower silhouette
                    drawRect(
                        color = Color(0xFF1B2230),
                        topLeft = Offset(w * 0.22f, h * 0.24f),
                        size = Size(w * 0.08f, h * 0.45f)
                    )
                    val spire = Path().apply {
                        moveTo(w * 0.21f, h * 0.24f)
                        lineTo(w * 0.26f, h * 0.10f)
                        lineTo(w * 0.31f, h * 0.24f)
                        close()
                    }
                    drawPath(spire, color = Color(0xFF1B2230))
                }
                "VINYL_NIGHT" -> {
                    drawRect(
                        brush = Brush.linearGradient(
                            listOf(Color(0xFF1D222D), Color(0xFF333B4D))
                        )
                    )
                    drawRoundRect(
                        color = Color(0xFF8D5B4C),
                        topLeft = Offset(w * 0.14f, h * 0.12f),
                        size = Size(w * 0.72f, h * 0.76f),
                        cornerRadius = CornerRadius(10f, 10f)
                    )
                    drawCircle(
                        color = Color(0xFF121212),
                        radius = h * 0.32f,
                        center = Offset(w * 0.45f, h * 0.50f)
                    )
                    drawCircle(
                        color = Color(0xFF3A3A3A),
                        radius = h * 0.23f,
                        center = Offset(w * 0.45f, h * 0.50f),
                        style = Stroke(width = 2f)
                    )
                    drawCircle(
                        color = Color(0xFFE07A5F),
                        radius = h * 0.10f,
                        center = Offset(w * 0.45f, h * 0.50f)
                    )
                    drawCircle(
                        color = Color.White,
                        radius = h * 0.025f,
                        center = Offset(w * 0.45f, h * 0.50f)
                    )
                    drawLine(
                        color = Color(0xFFD9D9D9),
                        start = Offset(w * 0.76f, h * 0.22f),
                        end = Offset(w * 0.60f, h * 0.55f),
                        strokeWidth = 6f
                    )
                }
                else -> {
                    // ROAD_TRIP
                    drawRect(
                        brush = Brush.verticalGradient(
                            listOf(Color(0xFF4CA1AF), Color(0xFFC4E0E5))
                        )
                    )
                    drawRect(
                        color = Color(0xFF2B6777),
                        topLeft = Offset(0f, h * 0.58f),
                        size = Size(w, h * 0.42f)
                    )
                    val road = Path().apply {
                        moveTo(w * 0.42f, h * 0.58f)
                        lineTo(w * 0.58f, h * 0.58f)
                        lineTo(w * 0.85f, h)
                        lineTo(w * 0.15f, h)
                        close()
                    }
                    drawPath(road, color = Color(0xFF37474F))
                    drawLine(
                        color = Color(0xFFFFCA28),
                        start = Offset(w * 0.50f, h * 0.62f),
                        end = Offset(w * 0.50f, h * 0.96f),
                        strokeWidth = 4f
                    )
                    drawCircle(
                        color = Color(0xFFFFF8E1),
                        radius = h * 0.14f,
                        center = Offset(w * 0.24f, h * 0.28f)
                    )
                }
            }
        }
        Text(
            text = "${sceneMeta.label} • ${sceneMeta.caption}",
            color = BlueWallColors.TextSecondary,
            fontSize = 11.sp,
            modifier = Modifier
                .fillMaxWidth()
                .background(BlueWallColors.SubBarSurface)
                .padding(horizontal = 10.dp, vertical = 6.dp)
        )
    }
}
