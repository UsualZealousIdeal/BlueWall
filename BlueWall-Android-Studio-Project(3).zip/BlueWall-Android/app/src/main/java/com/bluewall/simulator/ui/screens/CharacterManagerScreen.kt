package com.bluewall.simulator.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bluewall.simulator.data.local.entity.CharacterEntity
import com.bluewall.simulator.ui.components.CharacterAvatar
import com.bluewall.simulator.ui.theme.BlueWallColors

@Composable
fun CharacterManagerScreen(
    characters: List<CharacterEntity>,
    activeCharacter: CharacterEntity?,
    onCreateCharacterClick: () -> Unit,
    onSwitchCharacter: (CharacterEntity) -> Unit,
    onViewProfile: (Long) -> Unit,
    onEditCharacter: (CharacterEntity) -> Unit,
    onDuplicateCharacter: (CharacterEntity) -> Unit,
    onRequestDeleteCharacter: (CharacterEntity) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(BlueWallColors.FeedBackground),
        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Prominent Currently Selected Character card
        item(key = "active_banner") {
            Surface(
                shape = RoundedCornerShape(4.dp),
                color = BlueWallColors.CardWhite,
                border = BorderStroke(1.5.dp, BlueWallColors.ClassicBlue)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(BlueWallColors.ClassicBlue)
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "CURRENTLY SELECTED CHARACTER",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.6.sp
                        )
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = Color(0xFF8EF083),
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    if (activeCharacter != null) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CharacterAvatar(character = activeCharacter, size = 54.dp)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = activeCharacter.name,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = BlueWallColors.TextPrimary
                                )
                                if (activeCharacter.headline.isNotBlank()) {
                                    Text(
                                        text = activeCharacter.headline,
                                        fontSize = 12.sp,
                                        color = BlueWallColors.TextSecondary,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            OutlinedButton(
                                onClick = { onViewProfile(activeCharacter.id) },
                                shape = RoundedCornerShape(3.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier.height(32.dp)
                            ) {
                                Text("View Wall", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }

        // Header & Create button
        item(key = "manager_actions") {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 2.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Fictional Characters (${characters.size})",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = BlueWallColors.TextPrimary
                    )
                    Text(
                        text = "No registration or passwords • Stored locally",
                        fontSize = 11.sp,
                        color = BlueWallColors.TextSecondary
                    )
                }

                Button(
                    onClick = onCreateCharacterClick,
                    shape = RoundedCornerShape(3.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = BlueWallColors.ClassicButtonBlue
                    ),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.height(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = null,
                        modifier = Modifier.size(17.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("New Character", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        items(characters, key = { it.id }) { character ->
            val isActive = character.id == activeCharacter?.id
            Surface(
                shape = RoundedCornerShape(4.dp),
                color = BlueWallColors.CardWhite,
                border = BorderStroke(
                    width = if (isActive) 1.5.dp else 1.dp,
                    color = if (isActive) BlueWallColors.ClassicBlue else BlueWallColors.CardBorder
                )
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        CharacterAvatar(
                            character = character,
                            size = 50.dp,
                            modifier = Modifier.clickable { onViewProfile(character.id) }
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = character.name,
                                    color = BlueWallColors.LinkBlue,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.clickable { onViewProfile(character.id) }
                                )
                                if (isActive) {
                                    Text(
                                        text = "ACTIVE",
                                        color = Color.White,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(3.dp))
                                            .background(BlueWallColors.ClassicBlue)
                                            .padding(horizontal = 5.dp, vertical = 1.dp)
                                    )
                                }
                            }
                            if (character.headline.isNotBlank()) {
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = character.headline,
                                    color = BlueWallColors.TextPrimary,
                                    fontSize = 12.sp,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            val meta = listOf(character.workplaceOrSchool, character.hometown)
                                .filter { it.isNotBlank() }
                                .joinToString(" • ")
                            if (meta.isNotBlank()) {
                                Spacer(modifier = Modifier.height(3.dp))
                                Text(
                                    text = meta,
                                    color = BlueWallColors.TextMuted,
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }

                    HorizontalDivider(color = BlueWallColors.SubtleDivider)

                    // Switch / Profile / Edit / Duplicate / Delete row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(BlueWallColors.SubBarSurface)
                            .padding(horizontal = 6.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        if (isActive) {
                            TextButton(
                                onClick = { onViewProfile(character.id) },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = null,
                                    tint = BlueWallColors.ClassicBlue,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Wall",
                                    color = BlueWallColors.ClassicBlue,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        } else {
                            Button(
                                onClick = { onSwitchCharacter(character) },
                                shape = RoundedCornerShape(3.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = BlueWallColors.ClassicButtonBlue
                                ),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier.height(30.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.SwapHoriz,
                                    contentDescription = null,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Switch", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TextButton(
                                onClick = { onEditCharacter(character) },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "Edit",
                                    tint = BlueWallColors.TextSecondary,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text("Edit", color = BlueWallColors.TextSecondary, fontSize = 12.sp)
                            }

                            TextButton(
                                onClick = { onDuplicateCharacter(character) },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ContentCopy,
                                    contentDescription = "Duplicate",
                                    tint = BlueWallColors.TextSecondary,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text("Duplicate", color = BlueWallColors.TextSecondary, fontSize = 12.sp)
                            }

                            TextButton(
                                onClick = { onRequestDeleteCharacter(character) },
                                enabled = characters.size > 1,
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DeleteOutline,
                                    contentDescription = "Delete",
                                    tint = if (characters.size > 1) BlueWallColors.DangerRed else BlueWallColors.TextMuted,
                                    modifier = Modifier.size(15.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
