package com.bluewall.simulator.data.repository

import com.bluewall.simulator.data.local.SeedData
import com.bluewall.simulator.data.local.dao.CharacterDao
import com.bluewall.simulator.data.local.dao.PostDao
import com.bluewall.simulator.data.local.entity.CharacterEntity
import com.bluewall.simulator.data.local.entity.CommentEntity
import com.bluewall.simulator.data.local.entity.PostEntity
import com.bluewall.simulator.data.local.entity.PostLikeEntity
import com.bluewall.simulator.data.local.model.PostWithDetails
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class SimulatorRepository(
    private val characterDao: CharacterDao,
    private val postDao: PostDao
) {
    private val seedMutex = Mutex()

    fun observeAllCharacters(): Flow<List<CharacterEntity>> =
        characterDao.observeAllCharacters()

    fun observeActiveCharacter(): Flow<CharacterEntity?> =
        characterDao.observeActiveCharacter()

    fun observeCharacterById(id: Long): Flow<CharacterEntity?> =
        characterDao.observeCharacterById(id)

    fun observeFeedPosts(): Flow<List<PostWithDetails>> =
        postDao.observeFeedPosts()

    fun observeWallPosts(characterId: Long): Flow<List<PostWithDetails>> =
        postDao.observeWallPosts(characterId)

    suspend fun ensureInitialized() {
        seedMutex.withLock {
            if (characterDao.countCharacters() == 0) {
                SeedData.populate(characterDao, postDao)
            } else if (characterDao.countActiveCharacters() == 0) {
                characterDao.getFirstCharacter()?.let { first ->
                    characterDao.switchActiveCharacter(first.id)
                }
            }
        }
    }

    suspend fun switchActiveCharacter(characterId: Long) {
        characterDao.switchActiveCharacter(characterId)
    }

    suspend fun createCharacter(
        name: String,
        headline: String,
        workplaceOrSchool: String,
        hometown: String,
        relationshipStatus: String,
        avatarStyle: String,
        avatarColorHex: Long,
        coverColorHex: Long,
        profilePhotoPath: String? = null,
        coverPhotoPath: String? = null,
        switchToNew: Boolean = true
    ): Long {
        val trimmedName = name.trim()
        require(trimmedName.isNotEmpty()) { "Character name cannot be blank." }

        val entity = CharacterEntity(
            name = trimmedName,
            headline = headline.trim(),
            workplaceOrSchool = workplaceOrSchool.trim(),
            hometown = hometown.trim(),
            relationshipStatus = relationshipStatus.trim(),
            avatarStyle = avatarStyle,
            avatarColorHex = avatarColorHex,
            coverColorHex = coverColorHex,
            profilePhotoPath = profilePhotoPath,
            coverPhotoPath = coverPhotoPath,
            isActive = false,
            createdAt = System.currentTimeMillis()
        )
        val newId = characterDao.insert(entity)
        if (switchToNew || characterDao.countCharacters() == 1) {
            characterDao.switchActiveCharacter(newId)
        }
        return newId
    }

    suspend fun updateCharacter(character: CharacterEntity) {
        val trimmedName = character.name.trim()
        require(trimmedName.isNotEmpty()) { "Character name cannot be blank." }
        characterDao.update(
            character.copy(
                name = trimmedName,
                headline = character.headline.trim(),
                workplaceOrSchool = character.workplaceOrSchool.trim(),
                hometown = character.hometown.trim(),
                relationshipStatus = character.relationshipStatus.trim()
            )
        )
    }

    suspend fun duplicateCharacter(
        source: CharacterEntity,
        copiedProfilePhotoPath: String? = source.profilePhotoPath,
        copiedCoverPhotoPath: String? = source.coverPhotoPath,
        switchToCopy: Boolean = false
    ): Long {
        val copyName = "${source.name} (Copy)"
        val copy = source.copy(
            id = 0L,
            name = copyName,
            profilePhotoPath = copiedProfilePhotoPath,
            coverPhotoPath = copiedCoverPhotoPath,
            isActive = false,
            createdAt = System.currentTimeMillis()
        )
        val newId = characterDao.insert(copy)
        if (switchToCopy) {
            characterDao.switchActiveCharacter(newId)
        }
        return newId
    }

    suspend fun deleteCharacter(character: CharacterEntity): Boolean {
        val total = characterDao.countCharacters()
        if (total <= 1) {
            return false
        }
        val wasActive = character.isActive
        characterDao.deleteById(character.id)
        if (wasActive) {
            val replacement = characterDao.getFirstCharacter()
            if (replacement != null) {
                characterDao.switchActiveCharacter(replacement.id)
            }
        }
        return true
    }

    suspend fun createPost(
        authorId: Long,
        targetProfileId: Long?,
        content: String,
        moodOrLocation: String?,
        photoSceneKey: String?,
        mediaPhotoPath: String? = null
    ) {
        val cleanContent = content.trim()
        if (cleanContent.isEmpty() && photoSceneKey == null && mediaPhotoPath == null) return

        val resolvedTarget = if (targetProfileId == authorId) null else targetProfileId
        postDao.insertPost(
            PostEntity(
                authorId = authorId,
                targetProfileId = resolvedTarget,
                content = cleanContent,
                moodOrLocation = moodOrLocation?.trim()?.takeIf { it.isNotEmpty() },
                photoSceneKey = if (mediaPhotoPath != null) null else photoSceneKey,
                mediaPhotoPath = mediaPhotoPath,
                createdAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun deletePost(postId: Long) {
        postDao.deletePostById(postId)
    }

    suspend fun addComment(postId: Long, authorId: Long, content: String) {
        val cleanContent = content.trim()
        if (cleanContent.isEmpty()) return
        postDao.insertComment(
            CommentEntity(
                postId = postId,
                authorId = authorId,
                content = cleanContent,
                createdAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun deleteComment(commentId: Long) {
        postDao.deleteCommentById(commentId)
    }

    suspend fun toggleLike(postId: Long, characterId: Long) {
        if (postDao.hasLiked(postId, characterId)) {
            postDao.deleteLike(postId, characterId)
        } else {
            postDao.insertLike(
                PostLikeEntity(
                    postId = postId,
                    characterId = characterId,
                    createdAt = System.currentTimeMillis()
                )
            )
        }
    }
}
