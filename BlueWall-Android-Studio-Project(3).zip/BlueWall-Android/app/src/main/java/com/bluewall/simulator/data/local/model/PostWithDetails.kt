package com.bluewall.simulator.data.local.model

import androidx.room.Embedded
import androidx.room.Relation
import com.bluewall.simulator.data.local.entity.CharacterEntity
import com.bluewall.simulator.data.local.entity.CommentEntity
import com.bluewall.simulator.data.local.entity.PostEntity
import com.bluewall.simulator.data.local.entity.PostLikeEntity

data class CommentWithAuthor(
    @Embedded val comment: CommentEntity,
    @Relation(
        parentColumn = "authorId",
        entityColumn = "id"
    )
    val author: CharacterEntity
)

data class PostLikeWithAuthor(
    @Embedded val like: PostLikeEntity,
    @Relation(
        parentColumn = "characterId",
        entityColumn = "id"
    )
    val character: CharacterEntity
)

data class PostWithDetails(
    @Embedded val post: PostEntity,
    @Relation(
        parentColumn = "authorId",
        entityColumn = "id"
    )
    val author: CharacterEntity,
    @Relation(
        parentColumn = "targetProfileId",
        entityColumn = "id"
    )
    val targetProfile: CharacterEntity?,
    @Relation(
        entity = CommentEntity::class,
        parentColumn = "id",
        entityColumn = "postId"
    )
    val comments: List<CommentWithAuthor>,
    @Relation(
        entity = PostLikeEntity::class,
        parentColumn = "id",
        entityColumn = "postId"
    )
    val likes: List<PostLikeWithAuthor>
)
