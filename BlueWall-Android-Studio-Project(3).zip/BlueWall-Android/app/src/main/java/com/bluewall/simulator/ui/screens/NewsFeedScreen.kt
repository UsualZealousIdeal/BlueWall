package com.bluewall.simulator.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bluewall.simulator.data.local.entity.CharacterEntity
import com.bluewall.simulator.data.local.model.PostWithDetails
import com.bluewall.simulator.ui.components.PostCard
import com.bluewall.simulator.ui.components.PostComposerCard
import com.bluewall.simulator.ui.theme.BlueWallColors

@Composable
fun NewsFeedScreen(
    activeCharacter: CharacterEntity?,
    posts: List<PostWithDetails>,
    onSwitchCharacterClick: () -> Unit,
    onAuthorClick: (Long) -> Unit,
    onPublishPost: (
        content: String,
        moodOrLocation: String?,
        photoSceneKey: String?,
        mediaPhotoPath: String?
    ) -> Unit,
    onToggleLike: (Long) -> Unit,
    onAddComment: (postId: Long, content: String) -> Unit,
    onDeletePost: (Long) -> Unit,
    onDeleteComment: (Long) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(BlueWallColors.FeedBackground),
        contentPadding = PaddingValues(top = 4.dp, bottom = 24.dp)
    ) {
        item(key = "composer") {
            PostComposerCard(
                activeCharacter = activeCharacter,
                wallTargetCharacter = null,
                onSwitchCharacterClick = onSwitchCharacterClick,
                onPublishPost = onPublishPost
            )
        }

        if (posts.isEmpty()) {
            item(key = "empty_feed") {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 8.dp),
                    shape = RoundedCornerShape(4.dp),
                    color = BlueWallColors.CardWhite,
                    border = BorderStroke(1.dp, BlueWallColors.CardBorder)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "No posts on the News Feed yet",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = BlueWallColors.TextPrimary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Write a status update above as ${activeCharacter?.name ?: "your character"} to start the timeline.",
                            fontSize = 13.sp,
                            color = BlueWallColors.TextSecondary
                        )
                    }
                }
            }
        } else {
            items(posts, key = { it.post.id }) { postDetails ->
                PostCard(
                    postDetails = postDetails,
                    activeCharacter = activeCharacter,
                    onAuthorClick = onAuthorClick,
                    onToggleLike = onToggleLike,
                    onAddComment = onAddComment,
                    onDeletePost = onDeletePost,
                    onDeleteComment = onDeleteComment
                )
            }
        }
    }
}
