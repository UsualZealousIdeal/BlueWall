# BlueWall — Offline Fictional Social Network Simulator

A native Android application built with **Kotlin**, **Jetpack Compose**, and **Room (SQLite)** inspired by classic 2010–2012 social networking.

## Technical Guarantees
- **100% Native Android** (Kotlin + Jetpack Compose + Material 3)
- **Zero Internet / Network Permissions** (`AndroidManifest.xml` does not request `INTERNET` or `ACCESS_NETWORK_STATE`)
- **Zero WebViews, Zero Remote APIs, Zero Firebase, Zero Analytics/Ads**
- **Persistent On-Device Storage** via `androidx.room` SQLite database (`bluewall_offline.db`)
- **Pre-seeded on First Launch** with 5 fictional characters, 7 posts, wall-to-wall posts, likes, and comments

## Features
1. **Classic 2010–2012 Blue Navigation Bar & Tab Strip** (`News Feed`, `Profile / Wall`, `Characters`)
2. **Dark Slate Navigation Drawer** showing the active fictional character, quick character switcher, and feed navigation
3. **Fictional Character Manager**: Create, edit, duplicate, delete, and switch between fictional characters with zero passwords or registration
4. **Prominent Active Character Indicator** across the top bar, drawer, composer, and character manager
5. **Interactive News Feed & Wall-to-Wall Posting**: Create status posts with optional mood/location tags and offline vector-drawn photo scenes, like posts as the currently active character, and write comments

## Opening in Android Studio
1. Open **Android Studio** (Ladybug / Meerkat or newer recommended).
2. Choose **File -> Open...** and select the `android-project` folder.
3. Let Gradle sync and run the `app` configuration on an Android emulator or physical Android phone (API 26+).
